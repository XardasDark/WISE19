import tkinter
def ende():
    root.destroy()
root = tkinter.Tk()
root.title("Tolles Programm mit Pack")
b1 = tkinter.Label(root,text = "Dieser Text ist blau", fg = "blue")
b1.pack()
b2 = tkinter.Label(root,text = "Dieser Text ist rot", fg = "red")
b2.pack()
b3 = tkinter.Button (root, text = "Hier passiert nichts")
b3.pack()
b4 = tkinter.Button (root, text = "Beende mich", command = ende)
b4.pack()

root.mainloop()

"""
pack()
Platziert die Widgets automatisch im Fenster, basierend auf dem vorhanden Platz.
Alle Elemente werden horizontal oder vertikal ausgerichtet, weitere Unteroptionen
sind fill, expand und side.
"""
