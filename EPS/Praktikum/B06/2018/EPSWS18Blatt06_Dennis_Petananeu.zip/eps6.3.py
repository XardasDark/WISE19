def fkt(a, b):
    print ("\nin fkt: a, id(a) : ", a, id(a))
    print ("in fkt: b, id(b) : ", b, id(b))
    a += b
    print("Nach der Zuweisung: a, id(a) : ", a, id(a))
    return a

x = 1
y = 2

print("1: x, id(x) : ", x, id(x))
print("2: y, id(y) : ", y, id(y))

y = fkt(x, y)

print("\n3: x, id(x) : ", x, id(x))
print("y, id(y) : ", y, id(y))

x = [1, 2]
y = [2, 3]

print("\n4: x, id(x) : ", x, id(x))
print("y, id(y) : ", y, id(y))

y = fkt(x, y)

print("\n5: x, id(x) : ", x, id(x))
print("y, id(y) : ", y, id(y))
