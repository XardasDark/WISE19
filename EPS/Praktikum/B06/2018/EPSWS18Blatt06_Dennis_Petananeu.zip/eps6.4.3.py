import tkinter
root=tkinter.Tk()
root.title("Ein Tolles Programm mit Place")
root.geometry('200x300')
l1 = tkinter.Label(text="Position, x=100, y=50", fg="white", bg="green")
l1.place(x=40, y=50)
l2 = tkinter.Label(text="Position, x=200, y=50", fg="black", bg="magenta")
l2.place(x=20, y=100)
l3 = tkinter.Label(text="Position, x=100, y=150", fg="black", bg="cyan")
l3.place(x=60, y=150)
l4 = tkinter.Label(text="Position, x=250, y=400", fg="white", bg="brown")
l4.place(x=40, y=200)
root.mainloop()

"""
place()
Platziert Widgets anhand von spezifischen x- und y-Koordinaten im Fenster.
Hierbei wird die Größe und Position der Widgets nicht von der Größe des Fensters
beeinflusst.
"""
