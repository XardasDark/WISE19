import tkinter
root = tkinter.Tk()
def ende():
    root.destroy()
root.title("Tolles Programm mit Grid")
l1 = tkinter.Label(root,text = "Dieser Text ist blau", fg = "blue")
l1.grid(row=0, column=1)
l2 = tkinter.Label(root,text = "Dieser Text ist rot", fg = "red")
l2.grid(row=1, column=2)
l3 = tkinter.Label(root,text = "Dieser Text ist gruen", fg = "green")
l3.grid(row=2, column=3)
b1 = tkinter.Button(text = "Dies beendet mich in orange", fg = "orange", command = ende)
b1.grid(row=3, column=4)
root.mainloop()

"""
grid()
Platziert die Widgets auf einem Raster basierend, kontrolliert durch Angabe von
Zeile und Spalte, der Rest geschieht automatisch.
"""
