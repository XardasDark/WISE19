wort = "test wort" # Global
def scopes():
    def do_local():
        wort = "local wort"
        print("in do-local: ", wort) # 3 Local
        return
    def do_nonlocal():
        nonlocal wort
        wort = "nonlocal wort"
        print("in do-nonlocal: ", wort) # 5 Nonlocal
        return
    def do_global():
        global wort
        wort = "global wort"
        print("in do-global: ", wort) # 7 Global
        return
    wort = "scope-Wort"
    print("in scopes: ", wort) # 2 Local
    do_local()
    print("Nach do_local:", wort) # 4 Local
    do_nonlocal()
    print("Nach do_nonlocal():", wort) # 6 Nonlocal
    do_global()
    print("Nach do_global:", wort) # 8 Nonlocal
    return
print(wort) # 1
scopes()
print("Globaler Scope:", wort) # 9 Global

"""
test wort
in scopes:  scope-Wort
in do-local:  local wort
Nach do_local: scope-Wort
in do-nonlocal:  nonlocal wort
Nach do_nonlocal(): nonlocal wort
in do-global:  global wort
Nach do_global: nonlocal wort
Globaler Scope: global wort
"""
