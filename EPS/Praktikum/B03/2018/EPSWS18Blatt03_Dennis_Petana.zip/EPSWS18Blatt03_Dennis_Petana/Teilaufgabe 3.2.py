# Alle Wörter in einem String
woerter = ["*", "**", "*#*", "****"]

# Beginne bei 0 bis länge des Arrays
for i in range(0, len(woerter)):
    # Setzte in TempWort das jeweilge Wort im Array ein
    tempWort = woerter[i]
    # Beginne bei 0 bis länge in TempWort
    for j in range(0, len(tempWort)):
        # Speichere in ausgabe das Array tempWort beginnent von j bis j+1. Alles andere schneide aus
        ausgabe = tempWort[j:j+1]
        # Beginne bei 0 bis länge in TempWort -1
        for k in range(0, len(tempWort)-1):
            #Speichere und füge jeweils das Wort an nullter Stelle im Array ausgabe ein.
            ausgabe += ausgabe[0]
        print(ausgabe)
