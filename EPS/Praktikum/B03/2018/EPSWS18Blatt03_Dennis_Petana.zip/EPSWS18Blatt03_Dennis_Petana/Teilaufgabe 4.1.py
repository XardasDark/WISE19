a = int(input("Gib eine Zahl ein! "))
while True:
     print (a)
     a = a + 1
     if a >= 10:
        break

# Teilaufgabe 4.2
# Testen mit einer Zahl <= 0
# Und mit einer Zahl >= 10
