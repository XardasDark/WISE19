a = 4
b = 16

if a == 0:
    print(b)
else:
    while b!= 0:
        if a > b:
            a = a - b
        else:
            b = b - a
    print(a)
