# Author Dennis Petana

# Erstelle eine leere Liste. Dieser Datentyp wurde gewählt da dieser mutabel ist und die Anordnung innerhalb der Liste sich leicht verändern lassen
speisekarte = []
# Versuche die Datei zu öffnen und zu lesen
try:
    file1 = open("speisekarte.txt", "r")
# Bei einem Problem erstelle sie
except IOError:
    file1 = open("speisekarte.txt", "w")
# Ansonsten gehe jede Zeile in der TXT-Datei durch, entferne alle Whitespaces/Absätze vor und nach dem String und füge sie nacheinander in die Liste ein
else:
    for line in file1:
        line = line.strip()
        speisekarte.append(line)
# Egal was passiert schließe die Datei
finally:
    file1.close()

# Menü-Steuerung
def options():
    menu = input(str("Gebe einen der folgenden Buchstaben ein:\na = Speisekarte anzeigen\nn = neues Gericht hinzufügen\np = Preis ändern\nl = Gericht löschen\ne = Speichern und Programmende\n"))
    if menu == "a":
        print_menu (speisekarte)
    elif menu == "n":
        add_dish (speisekarte)
    elif menu == "p":
        change_price (speisekarte)
    elif menu == "l":
        remove_dish (speisekarte)
    elif menu == "e":
        save_menu (speisekarte)
    else:
        print("Die Eingabe war unzulässig!\n")
        options()

# Zeigt alle Gerichte mit Preis auf der Speisekarte an
def print_menu(speisekarte):
    for dish in speisekarte:
        print(dish)
    options()

# Fügt ein neues Gericht der Speisekarte hinzu
def add_dish (speisekarte):
    isDone = False
    while isDone == False:
            # Wenn der Benutzer nichts eingibt gehe zurück ins Hauptmenü
            eingabe = input(str("Gebe ein, wie das neue Gericht heißen soll (Enter zum Abbrechen): "))
            if eingabe == "":
                isDone = True
            elif eingabe != "":
                price = input("Gebe ein, wieviel das neue Gericht in Cent kosten soll (Enter zum Abbrechen): ")
                if price == "":
                    isDone = True
                else:
                    try:
                        int(price)
                    except:
                        print(str(price) + " ist keine Zahl!\n")
                    else:
                        if int(price) <= 0:
                            print("Hier gibts nichts umsonst!\n")
                        # Wenn Eingabe des Benutzers nicht auf der Speisekarte existiert, füge diese hinzu und durchbreche die Schleife
                        elif speisekarte.count(eingabe + ";" + price) == 0:
                            speisekarte.append(eingabe + ";" + price)
                            print(eingabe + ";" + price + " wurde erfolgreich hinzugefügt!\n")
                            isDone = True
                        else:
                            print(eingabe + " existiert bereits auf der Speisekarte.\n")
    options()


# Ändert den Preis eines Gerichts
def change_price (speisekarte):
    for dish in speisekarte:
        print(str(speisekarte.index(dish)) + ": " + dish)
    isDone = False
    while isDone == False:
        eingabe = input("Gebe den Index des Gerichts an bei dem sich der Preis ändern soll (Enter zum Abbrechen): ")
        if eingabe == "":
            isDone = True
        else:
            try:
                int(eingabe)
            except:
                print(str(eingabe) + " ist keine Zahl!\n")
            else:
                # Schaue ob die Eingabe kleiner gleich 0 und ob sie out of range ist
                if int(eingabe) <= len(speisekarte) -1 and int(eingabe) >= 0:
                    price = input("Gebe den sich zu ändernden Preis an (Enter zum Abbrechen): ")
                    if price == "":
                        isDone = True
                    else:
                        try:
                            int(price)
                        except:
                            print(str(price) + " ist keine Zahl!\n")
                        else:
                            if int(price) <= 0:
                                print("Hier gibts nichts umsonst!\n")
                            else:
                                # Splitte das 1. Semikolon ganz rechts, den Rest speichere in oldname
                                oldname = speisekarte[int(eingabe)].rsplit(';',1)[0]
                                speisekarte[int(eingabe)] = oldname + ";" + str(price)
                                print(oldname + " kostet ab jetzt " + str(price) + "!\n")
                            isDone = True
                else:
                    print(str(eingabe) + " ist kein vorhandener Index!\n")
    options()

# Entfernt ein Gericht aus der Speisekarte
def remove_dish (speisekarte) :
    for dish in speisekarte:
        print(str(speisekarte.index(dish)) + ": " + dish)
    isDone = False
    while isDone == False:
        eingabe = input("Gebe den Index des zu löschenden Gerichts an (Enter zum Abbrechen): ")
        if eingabe == "":
            isDone = True
        else:
            try:
                int(eingabe)
            except:
                print(str(eingabe) + " ist keine Zahl!\n")
            else:
                # Schaue ob die Eingabe kleiner gleich 0 und ob sie out of range ist
                if int(eingabe) <= len(speisekarte) - 1 and int(eingabe) >= 0:
                    # Entferne das Gericht an der Stelle der Eingabe
                    entfernt = speisekarte.pop(int(eingabe))
                    print(entfernt + " wurde erfolgreich gelöscht!.\n")
                    isDone = True
                else:
                    print(str(eingabe) + " ist kein vorhandener Index!\n")
    options()

# Speichert alle Gerichte in die TXT-Datei
def save_menu (speisekarte):
    # Versuche die Datei zu überschreiben
    try:
        file1 = open("speisekarte.txt", "w")
    except IOError:
        print("\nEin Fehler ist aufgetreten. Ist die Datei vielleicht schreibgeschützt?")
        isDone2 = False
        while isDone2 == False:
            beenden = input(str("Möchtest du dennoch das Programm beenden? Schreibe ja oder nein: "))
            # Wenn Programm beendet werden soll, schließe die Bearbeitung der Speisekarte und beende das Programm
            if beenden == "ja":
                print("Programm beendet!")
                isDone2 = True
            elif beenden == "nein":
                print("\n")
                options()
            else:
                print("\nDie Eingabe war unzulässig!\n") 
    else:
        # Wenn Speisekarte ist beschreibbar gehe jedes Objekt der Speisekarten-Liste durch und schreibe sie in die TXT-Datei mit einem Absatz
        # Danach schließe die Bearbeitung der TXT-Datei und beende das Programm
        for dish in speisekarte:
            file1.write(dish+"\n")
        file1.close()
        print("Programm beendet!")
        isEingabe = True

#Programm startet von hier
options()
