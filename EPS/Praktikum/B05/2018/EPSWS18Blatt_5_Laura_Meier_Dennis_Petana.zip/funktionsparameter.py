# Author Dennis Petana

def default(x=1):
    print(x)
def position(y):
    print(y)
def benannt(z):
    print(z)
def packing(*args):
    print(args)
def unpacking(a, b, c, d):
    print(a, b, c, d)

default()
position(2)
benannt(z=3)
packing(1,2,"a","b")
unpacking(*[1,2,"a","b"])
