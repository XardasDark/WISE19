# Author Dennis Petana

def hoch(i,x=2) :
    #Wenn es eine Nummer ist
    if isinstance(x,int) and isinstance(i,int):
        return  print(calc(x,i))
    else:
        print("Bitte Zahlen eingeben!\n")

def calc(x,i) :
            if i == 0:
                return 1
            elif i == 1:
                return x
            else:
                #return x * die Funktion mit den neuen Parametern und i-1
                #calc(4,2)
                #return 2 * calc(2,3) -> 16
                #return 2 * calc(2,2) -> 8
                #return 2 * calc(2,1) -> 4
                return x * calc(x,i-1)
x = 4
i = 3
hoch (i,x)
