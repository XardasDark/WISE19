# Author Dennis Petana

# Erstelle eine leere Liste
speisekarte = []
# Versuche die Datei zu öffnen und zu lesen
try:
    file1 = open("speisekarte.txt", "r")
# Bei einem Problem erstelle sie
except IOError:
    file1 = open("speisekarte.txt", "w")
# Ansonsten gehe jede Zeile in der TXT-Datei durch, entferne alle Whitespaces/Absätze vor und nach dem String und füge sie nacheinander in die Liste ein
else:
    for line in file1:
        line = line.strip()
        speisekarte.append(line)
# Solange False bleibe im Hauptmenü
isEingabe = False
while isEingabe == False:
    # Benutzer gibt seine Auswahl ein. Wird zu einem String gecasted, damit illegale Char's das Programm nicht crashen
    menu = input(str("\nGebe einen der folgenden Buchstaben ein:\na = Speisekarte anzeigen\nn = neues Gericht hinzufügen\ne = Speichern und Programmende\n"))
    if menu == "a":
        # Gibt die Speisekarte aus
        for dish in speisekarte:
            print(dish)
    elif menu == "n":
        isDone = False
        while isDone == False:
            menu2 = input(str("Gebe ein, wie das neue Gericht heißen soll (Enter zum Abbrechen): "))
            # Wenn der Benutzer nichts eingibt gehe zurück ins Hauptmenü
            if menu2 == "":
                isDone = True
            elif menu2 != "":
                # Wenn Eingabe des Benutzers nicht auf der Speisekarte existiert, füge diese hinzu und durchbreche die Schleife
                if speisekarte.count(menu2) == 0:
                    speisekarte.append(menu2)
                    print("\n" + menu2 + " wurde erfolgreich hinzugefügt!")
                    isDone = True
                else:
                    print("\n" + menu2 + " existiert bereits auf der Speisekarte.\n")
    elif menu == "e":
        # Versuche die Datei zu überschreiben
        try:
            file1 = open("speisekarte.txt", "w")
        except IOError:
            print("\nEin Fehler ist aufgetreten. Ist die Datei vielleicht schreibgeschützt?")
            isDone2 = False
            while isDone2 == False:
                beenden = input(str("Möchtest du dennoch das Programm beenden? Schreibe ja oder nein: "))
                # Wenn Programm beendet werden soll, schließe die Bearbeitung der Speisekarte und beende das Programm
                if beenden == "ja":
                    file1.close()
                    print("Programm beendet!")
                    isEingabe = True
                    isDone2 = True
                elif beenden == "nein":
                    isDone2 = True
                    isEingabe = False
                    print("\n")
                else:
                    print("\nDie Eingabe war unzulässig!\n")
            
        else:
            # Wenn Speisekarte ist beschreibbar gehe jedes Objekt der Speisekarten-Liste durch und schreibe sie in die TXT-Datei mit einem Absatz
            # Danach schließe die Bearbeitung der TXT-Datei und beende das Programm
            for dish in speisekarte:
                file1.write(dish+"\n")
            file1.close()
            print("Programm beendet!")
            isEingabe = True
    else:
        print("\nDie Eingabe war unzulässig!")
