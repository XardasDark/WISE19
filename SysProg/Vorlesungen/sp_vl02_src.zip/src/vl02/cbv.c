/*
 * cbv.c
 *
 * Author: Carsten Gips
 *
 * `gcc -Wall cbv.c`
 *
 */

#include <stdio.h>

int add_5(int);

int main() {
    int erg, i = 0;
    printf("i: %d\n", i);

    erg = add_5(i);
    printf("\nerg: %d\n", erg);
    printf("i: %d\n", i);
    return 0;
}

int add_5(int x) {
    x += 5;
    return x;
}
