/*
 * limits.c
 *
 * Author: Carsten Gips
 *
 * `gcc -Wall limits.c`
 *
 */

#include <stdio.h>
#include <limits.h>

int main() {
    printf("sizeof(unsigned char): \t'%d'\n\n", sizeof(unsigned char));

    printf("sizeof(short int): \t'%d'\n\n", sizeof(short int));

    printf("sizeof(int): \t\t'%d'\n", sizeof(int));
    printf("sizeof(long int): \t'%d'\n\n", sizeof(long int));

    printf("sizeof(float): \t\t'%d'\n", sizeof(float));
    printf("sizeof(double): \t'%d'\n", sizeof(double));
    printf("sizeof(long double): \t'%d'\n", sizeof(long double));

    printf("\nINT_MAX: \t%d\n", INT_MAX);
    printf("INT_MIN: \t%d\n", INT_MIN);

    return 0;
}
