/*
 * funcvoid.c
 *
 * Author: Carsten Gips
 *
 * `gcc -Wall funcvoid.c`
 *
 */

#include <stdio.h>

int f1(void);

int f2();

int f3();

int main() {
    /* legaler Gebrauch */
    f1();
    f2();
    f3(42);

    /* falscher Gebrauch */
    f1(42);     /* Compilermeldung */
    f2(42);     /* LEGAL!          */
    f3(42, 43); /* LEGAL!          */

    return 0;
}

int f1(void) {
    printf("Huhu von f1\n");
    return 0;
}

int f2() {
    printf("Huhu von f2\n");
    return 0;
}

int f3(int a) {
    printf("Huhu von f3: a=%d\n", a);
    return 0;
}
