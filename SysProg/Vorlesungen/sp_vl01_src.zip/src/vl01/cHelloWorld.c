/*
 * cHelloWorld.c
 *
 * Author: Carsten Gips
 *
 * `gcc -Wall cHelloWorld.c`
 *
 */

#include <stdio.h>

int main() {
    // C++-Style Comment ...
    printf("Hello World from C  :-)\n");

    return 0;
}
