/*
 * fkt.c
 *
 * Author: Carsten Gips
 */

#include <stdio.h>

#include "fkt.h"

void fkt() {
    printf("Hello World :-) \n");
}
