/*
 ============================================================================
 Name        : main.c
 Author      : Carsten Gips
 ============================================================================
*/

#include <stdio.h>
#include <stdlib.h>

#include "fkt.h"

int main(void) {
    fkt();
    return EXIT_SUCCESS;
}
