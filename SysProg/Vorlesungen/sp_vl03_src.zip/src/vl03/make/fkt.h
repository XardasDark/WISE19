/*
 * fkt.h
 *
 * Author: Carsten Gips
 */

#ifndef FKT_H
#define FKT_H

void fkt();

#endif /* FKT_H */
