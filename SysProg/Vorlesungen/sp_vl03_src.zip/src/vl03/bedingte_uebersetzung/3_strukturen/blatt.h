/*
 * blatt.h
 *
 * Author: Carsten Gips
 *
 *
 */

#include "struct.h"

void fkt1();

void fkt2();

int wuppie(struct studi);
