/*
 * struct.h
 *
 * Author: Carsten Gips
 *
 *
 */

struct studi {
    char *name;
    unsigned int credits;
};
