/*
 * main.c
 *
 * Author: Carsten Gips
 *
 */

#include "ledbar.h"

/* Demo */
int main(void) {
    init_led_bar();
    set_led(LED01, FULL);
}
