/*
 * main.c
 *
 * Author: Carsten Gips
 *
 * `gcc main.c`
 *
 * `gcc -c main.c;  gcc -c blatt.c;  gcc main.o blatt.o`
 *
 */

#include "blatt.c"

int main() {
    fkt1();
    fkt2();
}
