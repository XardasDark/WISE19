/*
 * blatt.h
 *
 * Author: Carsten Gips
 *
 *
 */

#ifndef BLATT_H
#define BLATT_H


#include "struct.h"

void fkt1();

void fkt2();

int wuppie(struct studi);


#endif   /* BLATT_H */
