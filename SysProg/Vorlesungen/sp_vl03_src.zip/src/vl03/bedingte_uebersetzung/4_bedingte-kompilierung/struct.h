/*
 * struct.h
 *
 * Author: Carsten Gips
 *
 *
 */

#ifndef STRUCT_H
#define STRUCT_H


struct studi {
    char *name;
    unsigned int credits;
};


#endif   /* STRUCT_H */
