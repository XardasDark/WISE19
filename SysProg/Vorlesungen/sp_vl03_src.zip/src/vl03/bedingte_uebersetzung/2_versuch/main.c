/*
 * main.c
 *
 * Author: Carsten Gips
 *
 * `gcc -c main.c;  gcc -c blatt.c;  gcc main.o blatt.o`
 *
 */

#include "blatt.h"

int main() {
    fkt1();
    fkt2();
}
