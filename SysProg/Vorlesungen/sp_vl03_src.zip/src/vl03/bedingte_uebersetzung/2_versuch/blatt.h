/*
 * blatt.h
 *
 * Author: Carsten Gips
 *
 *
 */

void fkt1();

void fkt2();
