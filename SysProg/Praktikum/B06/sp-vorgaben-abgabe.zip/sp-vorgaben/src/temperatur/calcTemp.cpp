//
// Created by viddie on 09.12.18.
//

#include <stdio.h>
#include "temperatur/calcTemp.h"

using namespace std;

float calculateTemperature(int raw){
    return (((float)raw * PI_VOLT / BITS - 0.5) * 100.0) + TEMP_CORRECTION;
}
