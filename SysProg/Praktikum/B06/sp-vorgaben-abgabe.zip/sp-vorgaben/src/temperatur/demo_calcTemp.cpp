//
// Created by viddie on 09.12.18.
//

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctime>
#include "temperatur/calcTemp.h"
#include "temperatur/tempSensor.h"
#include "temperatur/sql_api.h"
#include "ringbuffer/ringbuffer.h"
#include "ledanzeige/TM1637.h"

using namespace std;

static float avgTemperatureInside(ring_buffer *rb){
    int countFields = 0;
    float total = 0.0f;
    float *valPtr;

    while(true){
        valPtr = (float *) read_buffer(rb);
        if(!valPtr){
            break;
        }
        countFields++;
        total += *valPtr;
    }

    float avgTemperature = total / (float) countFields;

    char str[200];
    sprintf(str, "countFields: '%d', total: '%.3f', AVG:  '%.3f'", countFields, total, avgTemperature);
    printDebug(str);

    return avgTemperature;
}

static std::string getCurrentTimeStamp(){
    time_t rawtime;
    struct tm * timeinfo;
    char buffer[80];

    time (&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(buffer,sizeof(buffer),"%d-%m-%Y %H:%M:%S",timeinfo);
    std::string str(buffer);

    return str;
}

int main(){

    bool running = true;
    ring_buffer *rb = init_buffer(10, free);
    TempSensor tempSens(calculateTemperature);
    int loopCount = 0;
    Sql_api dbConnection;

    TM1637_setup();

    while (running){
        float *temperature = (float *) malloc(sizeof(float));
        *temperature = tempSens.getTemp();
        write_buffer(rb, temperature);

        float percentUsed = (float) rb->count / (float) rb->size;
        percentUsed *= 100;

        char str[200];
        sprintf(str, "Innentemperatur: %.3f. Ringbuffer Füllstand: %.3f%%", *temperature, percentUsed);
        printDebug(str);

        TM1637_display_number(percentUsed);

        /*TM1637_display_number(*temperature);
        sleep(SLEEP_DURATION/2);*/

        if(++loopCount % LOOPCOUNT == 0){
            //Get temp in Minden
            float tempInMinden = 2.5f;
            std::string mindenStr = std::to_string(tempInMinden);



            float avg = avgTemperatureInside(rb);
            std::string insideStr = std::to_string(avg);

            sprintf(str, "Avg since last call: '%.3f', Temp in Minden: '%.3f'", avg, tempInMinden);
            printDebug(str);

            std::string date = getCurrentTimeStamp();

            //printDebug(mindenStr + "; "+insideStr+"; "+date);

            dbConnection.newEntry(std::to_string(loopCount), date, mindenStr, insideStr);
        }

        sleep(SLEEP_DURATION);
    }

}
