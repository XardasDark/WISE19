#include "smartpointer/pimpl.h"
#include <vector>

/**
 * struct in der die privaten Attribute von Person stehen
 */
struct person::Impl
{
    Impl(std::string name, int id):
            name(name), id(id){}
    std::string name;
    int id;

};
/**
 * Konstruktor von person
 *
 * @param name, Name der Person
 * @param id, wert der ID
 */
person::person(std::string name, int id)
        : pimpl(new Impl (name,id)){}

/**
 * Copykonstruktor von person, kopiert die Attribute.
 *
 * @param person, ein Opjekt von Person
 */
person::person(const person &p)
        : pimpl(new Impl(*p.pimpl)){}

/**
* Destruktor zum zerstören des Objekts
*/
person::~person(){};


/**
 * Eine Methode die den Namen einer Person ändert
 * @param name der person
 */
void person::setName(std::string name) {
    pimpl->name = name;
}

/**
 * Eine Methode die den String der in Namen steht zurückgibt.
 *
 * @return wert der in name steht
 */
std::string person::getName() const{
    return pimpl->name;
}

/**
 * Eine Methode die den Wert von ID zurück gibt.
 *
 * @return wert der in id steht
 */
int person::getId() const{
    return pimpl->id;
}
