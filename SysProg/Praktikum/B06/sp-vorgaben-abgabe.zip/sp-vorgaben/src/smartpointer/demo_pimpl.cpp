/**
 * Die Demo-Datei zur Darstellung des Pimpl-Idioms
*/
#include <iostream>
#include "smartpointer/pimpl.h"

/**
 * Die Methode, um Pimpl zu demonstrieren
 *
 * @return Standardwert nach Durchlauf der Main-Funktion
 */
int main(){
    person p1("Meier",55);
    person p2("Müller",23);
    std::cout << "1 " << p1.getName() << ":" << p1.getId() << "\n";
    std::cout << "2 " << p2.getName() << ":" << p2.getId() << "\n";

    p2.setName("Hans");
    std::cout << "2 " << p1.getName() << ":" << p1.getId() << "\n";

    return 0;
}
