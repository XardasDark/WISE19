/**
 * speicherverwaltung
 * @author ckrebel, hrueffer, dpetana
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "speicherverwaltung/speicherverwaltung.h"


char mempool[MEM_POOL_SIZE];
memblock *freemem;

/**
 * Initializes the mempool & freemem only once
 * @return 1 means success, 0 means they were already initialized, -1 means failure
 */
int cm_init(void) {
    static bool used = false;
    if(!used) {
        memblock *start = (memblock*)mempool;
        if(start)
        {
            used = true;
            start->size = MEM_POOL_SIZE-sizeof(memblock);
            start->next = NULL;
            start->id = 0;
            freemem = start;
            return 1;
        }
        else
        {
            return -1;
        }
    }
    else
    {
        return 0;
    }

}

/**
 * Allocates a certain amount of bytes to be used freely
 * @param size the amount of bytes to be allocated
 * @return a pointer to the first byte of the allocated space, or NULL if size <= 0, if the init failed or if no fitting block was found
 */
void * cm_malloc(size_t size){
    static int usedID = 1;

    if(size <= 0 || cm_init() == -1 || freemem == NULL || (char *) freemem < mempool || (char *) freemem > mempool + MEM_POOL_SIZE){
        return NULL;
    }

    memblock *before = NULL;
    memblock *current = freemem;

    do{
        if(current->size >= size){
            break;
        }
        before = current;
    }while((current = current->next));    // Repeat until current is a free block with enough space

    if(current == NULL || (char *) current < mempool || (char *) current > mempool + MEM_POOL_SIZE){    // No valid block was found
        return NULL;
    }


    // Splitting of blocks
    size_t splitAt = size + 2 * sizeof(memblock) + 32;

    char str[200];
    sprintf(str, "CurrentSize: '%lu', splitAt: '%lu', SPLIT: '%d'", current->size, splitAt, SPLIT);
    printDebug(str);

    if(current->size > splitAt && SPLIT){
        printDebug("Using split method");

        size_t oldSize = current->size;
        current->size = size;

        memblock *newBlock = (memblock *) (((char *)(current+1))+size);
        newBlock->size = oldSize - size - sizeof(memblock);
        newBlock->next = current->next;

        sprintf(str, "oldSize: '%lu', size: '%lu', sizeof(memblock): '%lu'", oldSize, size, sizeof(memblock));
        printDebug(str);

        void *ptr = (void *) (current + 1);
        current->id = usedID++;
        current->next = (memblock *) MAGIC_INT;

        if(before == NULL){    // freemem -> current -> NULL
            freemem = newBlock;

        }else{    // freemem -> ... -> current -> NULL
            before->next = newBlock;

        }

        return ptr;

    }else{
        printDebug("Not using split method");

        void *ptr = (void *) (current + 1);
        memblock *after = current->next;
        current->id = usedID++;
        current->next = (memblock *) MAGIC_INT;

        if(before == NULL && after == NULL){    // freemem -> current -> NULL
            freemem = NULL;

        }else if(before == NULL && after != NULL){    // freemem -> current -> ... -> NULL
            freemem = after;

        }else if(before != NULL && after == NULL){    // freemem -> ... -> current -> NULL
            before->next = NULL;

        }else if(before != NULL && after != NULL){    // freemem -> ... -> current -> ... -> NULL
            before->next = after;

        }

        return ptr;
    }
}

/**
 * Frees a memblock on which ptr points and adds it to the freemem list as the first entry
 * @param ptr the pointer to the memblock
 */
void cm_free(void *ptr) {
    // Is Nullpointer or not in Mempool
    if (ptr == NULL || (char*) ptr < mempool || (char*) ptr > (mempool + MEM_POOL_SIZE)) {
        printDebug("Failed to free the Pointer (is NULL or not in mempool).");
        return;
    }
    memblock *ptr2 = ((memblock*) ptr) -1;
    if (ptr2->next == (memblock*) MAGIC_INT) {
        if (freemem == NULL) {
            ptr2->next = NULL;
        } else {
            ptr2->next = freemem;
        }
        freemem = ptr2;
        printDebug("Pointer freed successfully!");
    } else {
        printDebug("Failed to free the Pointer (memblock has no MAGIC_INT).");
        return;
    }
}

/**
 * Gibt einen Pointer auf den freien Speicherblock VOR dem übergebenen in der Liste
 * Ist nötig, da es sich hier nur um eine einfach verkettete Liste handelt
 * @param block Pointer auf einen Memory-Block
 * @return Der Pointer auf den freien Speicher in der Liste vor dem übergebenen Speicher
 */
memblock *getPrevMemory(memblock *block) {
    memblock *tmp, *prev;
    tmp = freemem;
    prev = NULL;
    while(tmp != NULL) {
        if(prev != NULL && prev->next == block) {
            return prev;
        }
        prev = tmp;
        tmp = tmp->next;
    }
    return NULL;
}

/**
 * Gibt TRUE(1) zurück, wenn Pointer auf Memblock in Freispeicherliste ist.
 * Sonst wird FALSE(0) zurückgegeben
 * @param block Der Pointer auf eine Speicherteil
 * @return Boolean, ob Pointer auf freien Speicher zeigt
 */
int isInList(memblock *block) {
    memblock *tmp;
    tmp = freemem;

    while(tmp != NULL) {
        if(tmp == block) {
            return 1;
        }
        tmp = tmp ->next;
    }
    return 0;
}

/**
 * Defgramentiert
 */
void cm_defrag() {
    memblock *tmp;
    memblock *nextInMempool;
    memblock *prevNextIn;
    memblock *prevTmp;
    int vereint;
    vereint = 1;
    tmp = freemem;

    while(vereint) {
        vereint  = 0;
        tmp = freemem;
        while(tmp != NULL && !vereint) {
            nextInMempool = (memblock *) ((char *)(tmp + 1)+ tmp->size);
            if(isInList(nextInMempool)) {
                tmp->size = tmp->size + nextInMempool->size + sizeof(memblock);
                if(tmp->next == nextInMempool) {
                    tmp->next = nextInMempool->next;
                }else if(freemem == nextInMempool) {
                    prevTmp = getPrevMemory(tmp);
                    freemem = tmp;
                    if(prevTmp != NULL) {
                        prevTmp->next = tmp->next;
                        freemem->next = prevTmp;
                    }
                }
                prevNextIn = getPrevMemory(nextInMempool);
                if(prevNextIn != NULL) {
                    prevNextIn->next = nextInMempool->next;
                }
                vereint  = 1;
            }
            tmp = tmp->next;
        }
    }
}
/**
 * copies n bytes from memory area src to memory area dest. The memory areas must not overlap.
 * Problems that could occur:
 * - Undefined behaviour when dest and src memory areas overlap
 * - size_t could be too big to copy
 * - size_t could be too big to paste
 * @param dest where to paste (onwards)
 * @param src from where to copy (onwards)
 * @param n how much bytes
 * @return dest
 */
void *cm_memcpy(void *dest, const void *src, size_t n) {
    // Is Nullpointer or not in Mempool
    memblock *tsrc = ((memblock*) src) -1;
    memblock *tdest = ((memblock*) dest) -1;
    if (dest == NULL || (char*) dest < mempool || (char*) dest > (mempool + MEM_POOL_SIZE)) {
        printDebug("Failed to paste (dest is NULL or not in mempool).");
    } else if (src == NULL || (char*) src < mempool || (char*) src > (mempool + MEM_POOL_SIZE)) {
        printDebug("Failed to copy (src is NULL or not in mempool).");
    } else if (n == 0) {
        printDebug("n is 0.");
    } else if (tdest->next != (memblock*) MAGIC_INT || tsrc->next != (memblock*) MAGIC_INT) {
            printDebug("Failed to copy (src's or dest's next are not MAGIC_INT).");
    } else {

        // char is 1 byte
        char *destChar = (char*) dest;
        char *srcChar = (char*) src;
        for (int i=0; i<n; i++) {
            destChar[i] = srcChar[i];
        }
        printDebug("Successfully copied bytes from src to dest!");
    }
    return dest;
}

/**
 * Vergrößert bzw. verkleinert einen Speicherblock
 * @param ptr Pointer auf den Block der verändert werden soll
 * @param size Die neue Größe des Blocks
 */
void *cm_realloc(void *ptr, size_t size) {
    memblock *tmp;
    if(ptr == NULL) {
        return cm_malloc(size);
    }
    tmp = (memblock *) (((memblock *)ptr)-1);
    if(size == 0) {
        cm_free(ptr);
        return NULL;
    }else if(tmp->size == size || (unsigned long int)tmp->next != MAGIC_INT) {
        return ptr;
    }else {
        tmp = cm_malloc(size);
        if(tmp != NULL) {
            cm_memcpy(tmp,ptr,size);
            cm_free(ptr);
        }
    }
    return tmp;
}