//
// Created by Xardas Dark on 27.11.2018.
//
#include <stdlib.h>
#include "ringbuffer/ringbuffer.h"

/**
* Initialisiert einen Ringbuffer mit der gewünschten Größe
* @param size_t Die gewünschte Größe
* @param (*f)(void*) Callback Function um Elemente aus dem Speicher zu deallocaten
*/

ring_buffer *init_buffer(const size_t n, void (*f)(void *p)) {

    if (n <= 0 || !(*f)) return NULL;

    ring_buffer *ptr_ri_buff = (ring_buffer *) malloc(sizeof(ring_buffer));
    if (!ptr_ri_buff) return NULL;

    ptr_ri_buff->elems = (void **) malloc(n * sizeof(void *));

    if (!ptr_ri_buff->elems) return NULL;

    size_t row;

    for (row = 0; row < n; row++) {
        ptr_ri_buff->elems[row] = (void *) malloc(sizeof(void *));
        if (!ptr_ri_buff->elems[row]) return NULL;
    }

    ptr_ri_buff->head = 0;
    ptr_ri_buff->size = n;
    ptr_ri_buff->count = 0;
    ptr_ri_buff->free_callback = f;

    return ptr_ri_buff;
}

/**
* Gibt das letzte Element, was hinzugefügt wurde, zurück
* @param ring_buffer* Der Ringbuffer, von wo das letzte Element zurück gegeben werden soll
*/
void *read_buffer(ring_buffer *cb) {
    if (!cb) return NULL;
    else if (cb->size == 0 || cb->count == 0) return NULL;

    void *ptr_return = cb->elems[cb->head];

    if (cb->head == (cb->size - 1))cb->head = 0;
    else cb->head++;

    cb->count--;

    return ptr_return;
}

/**
* Fügt ein Element am Ende des Ringbuffers ein
* @param ring_buffer* Der Ringbuffer, wo das Element hinzugefügt werden soll
* @param void* Pointer zu dem Element, was hinzugefügt werden soll
*/
void write_buffer(ring_buffer *cb, void *data) {
    if (!cb || !data) return;
    else if (cb->size == 0)return;

    size_t pos;

    pos = (cb->count + cb->head) % cb->size;
    if (pos == cb->head && cb->count > 1) {
        cb->free_callback(cb->elems[pos]);
        cb->elems[pos] = data;
        if (cb->head == (cb->size - 1)) cb->head = 0;
        else cb->head++;
    } else {
        cb->elems[pos] = data;
    }
    if (!(cb->count == cb->size))cb->count++;
}

/**
 * Gibt Ringbuffer und dazugehörige Datensätze
 * ebenfalls frei (mittels des Funktionspointers free_callback).
 * @param cb der freizugebene Ringbuffer
 * @return Anzahl der ursprünglich gespeicherten Datensätze
 */
int free_buffer(ring_buffer *cb) {
    if (!cb || cb->count < 1) {
        return -1;
    }

    int zeile;
    for (zeile = 0; zeile < cb->count; zeile++) {
        //Iteriere über den ringbuffer vom head aus. Pass auf, dass man nicht zu weit geht und von vorne anfängt
        int eleIndex = (cb->head + zeile) % cb->size;
        cb->free_callback(cb->elems[eleIndex]);
        cb->elems[eleIndex] = NULL;
    }

    free(cb->elems);
    free(cb);
    cb = NULL;
    return zeile;
}

/**
 * Liefert die Anzahl der gespeicherten Elemente zurück.
 * Im Fehlerfall wird −1 zurück geliefert.
 * @param cb der Ringebuffer mit den Elementen
 * @return Anzahl der gespeicherten Elemente oder -1 für Fehler
 */
int count_elements(const ring_buffer *cb) {
    if (!cb) {
        return -1;
    }

    return (int) cb->count;
}
