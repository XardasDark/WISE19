var searchData=
[
  ['register_5fstudent',['register_student',['../pruefungen_8c.html#a5667a45fcd5c9d9f7bfdd07b7c89686a',1,'register_student(student *s, int nr):&#160;pruefungen.c'],['../pruefungen_8h.html#a5667a45fcd5c9d9f7bfdd07b7c89686a',1,'register_student(student *s, int nr):&#160;pruefungen.c']]],
  ['remove_5fstudent',['remove_student',['../pruefungen_8c.html#a1440341fbac4cb912e2354ed8ee41375',1,'remove_student(student *s):&#160;pruefungen.c'],['../pruefungen_8h.html#a1440341fbac4cb912e2354ed8ee41375',1,'remove_student(student *s):&#160;pruefungen.c']]]
];
