var searchData=
[
  ['show_5fall',['show_all',['../studiverwaltung_8c.html#abf059a18f94f7e71ec28c6306d5724ad',1,'show_all(node *head):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#abf059a18f94f7e71ec28c6306d5724ad',1,'show_all(node *head):&#160;studiverwaltung.c']]]
];
