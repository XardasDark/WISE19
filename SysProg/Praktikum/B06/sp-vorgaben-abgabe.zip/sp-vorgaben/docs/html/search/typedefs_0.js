var searchData=
[
  ['brightness',['brightness',['../segmentanzeige_8h.html#a21fbaf85b01621e4ca1ac11d6b1beb86',1,'segmentanzeige.h']]],
  ['byte',['byte',['../segmentanzeige_8h.html#a0c8186d9b9b7880309c27230bbb5e69d',1,'segmentanzeige.h']]]
];
