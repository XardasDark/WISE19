var searchData=
[
  ['dark',['DARK',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070a5564de0baf1f25257db17367eba68edd',1,'segmentanzeige.h']]]
];
