var searchData=
[
  ['get_5fifm_5fstudents',['get_ifm_students',['../studiverwaltung_8c.html#aba671dd44cdaec3cd330ad719d5724b4',1,'get_ifm_students(node *head):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#aba671dd44cdaec3cd330ad719d5724b4',1,'get_ifm_students(node *head):&#160;studiverwaltung.c']]],
  ['get_5flist_5forigin',['get_list_origin',['../studiverwaltung_8c.html#a71a77f88a67dbff9242e11ce679ad3ef',1,'get_list_origin(node *node):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#a71a77f88a67dbff9242e11ce679ad3ef',1,'get_list_origin(node *node):&#160;studiverwaltung.c']]],
  ['get_5flist_5ftail',['get_list_tail',['../studiverwaltung_8c.html#aab06078c619d5e5150b55d374e41037d',1,'studiverwaltung.c']]]
];
