var searchData=
[
  ['pflege',['PFLEGE',['../studiverwaltung_8h.html#afea1a0808a440b8bfe966975b78f8ffdab404e342c4a9833fd4f4ee540f65491e',1,'studiverwaltung.h']]]
];
