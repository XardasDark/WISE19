var searchData=
[
  ['dot',['dot',['../segmentanzeige_8h.html#aab918c44be8d33ac19b291d5c1ad200c',1,'segmentanzeige.h']]]
];
