var searchData=
[
  ['name',['name',['../structstudent.html#aaf96ffe0cd3e94f06fc06f0680bd88d4',1,'student']]],
  ['next',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]],
  ['number_5fto_5fbyte',['NUMBER_TO_BYTE',['../ledanzeige_2TM1637_8c.html#a0dbeb7a4ce21d585502c227905f7b799',1,'NUMBER_TO_BYTE():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a0dbeb7a4ce21d585502c227905f7b799',1,'NUMBER_TO_BYTE():&#160;TM1637.c']]]
];
