var searchData=
[
  ['tm1637_2ec',['TM1637.c',['../TM1637_8c.html',1,'']]],
  ['tm1637_2eh',['TM1637.h',['../TM1637_8h.html',1,'']]],
  ['tm1637_5fack',['TM1637_ack',['../TM1637_8c.html#a5c7dfde0103544fb5c7022f24e325ed6',1,'TM1637_ack():&#160;TM1637.c'],['../TM1637__intern_8h.html#a11841c7b2d40d2e9c9c669a7d97a34f2',1,'TM1637_ack(void):&#160;TM1637.c']]],
  ['tm1637_5fbrightness',['TM1637_brightness',['../TM1637_8c.html#a7eea12453b5ac2b52f0c986027e7d97b',1,'TM1637_brightness(brightness b):&#160;TM1637.c'],['../TM1637_8h.html#a15e1f79466c86447e80a67e115eece6b',1,'TM1637_brightness(brightness bright):&#160;TM1637.c']]],
  ['tm1637_5fcalculate_5fdisplay',['TM1637_calculate_display',['../TM1637_8c.html#a8b80fd9d744cf8777764beb96eb9332e',1,'TM1637_calculate_display(float number, segment seg):&#160;TM1637.c'],['../TM1637__intern_8h.html#a8b80fd9d744cf8777764beb96eb9332e',1,'TM1637_calculate_display(float number, segment seg):&#160;TM1637.c']]],
  ['tm1637_5fclear_5fdisplay',['TM1637_clear_display',['../TM1637_8c.html#abdf40785ea814191532c03857af06cf8',1,'TM1637_clear_display(void):&#160;TM1637.c'],['../TM1637_8h.html#abdf40785ea814191532c03857af06cf8',1,'TM1637_clear_display(void):&#160;TM1637.c']]],
  ['tm1637_5fclear_5fsegment',['TM1637_clear_segment',['../TM1637_8c.html#a1aa0cd3323af33490732c279f5111444',1,'TM1637_clear_segment(segment seg):&#160;TM1637.c'],['../TM1637_8h.html#a1aa0cd3323af33490732c279f5111444',1,'TM1637_clear_segment(segment seg):&#160;TM1637.c']]],
  ['tm1637_5fdisplay',['TM1637_display',['../TM1637_8c.html#a13011267937dc739977cf9688b24eade',1,'TM1637_display(segment seg, byte data, dot point):&#160;TM1637.c'],['../TM1637__intern_8h.html#a13011267937dc739977cf9688b24eade',1,'TM1637_display(segment seg, byte data, dot point):&#160;TM1637.c']]],
  ['tm1637_5fdisplay_5fnumber',['TM1637_display_number',['../TM1637_8c.html#ab1444bb5103a853caed9710801fee2d6',1,'TM1637_display_number(float number):&#160;TM1637.c'],['../TM1637_8h.html#ab1444bb5103a853caed9710801fee2d6',1,'TM1637_display_number(float number):&#160;TM1637.c']]],
  ['tm1637_5fintern_2eh',['TM1637_intern.h',['../TM1637__intern_8h.html',1,'']]],
  ['tm1637_5fsetup',['TM1637_setup',['../TM1637_8c.html#a1f485a2ea615d89fdc406c1b7c6b25bb',1,'TM1637_setup():&#160;TM1637.c'],['../TM1637_8h.html#a205d2b82e18a46a0c72713e911a818b8',1,'TM1637_setup(void):&#160;TM1637.c']]],
  ['tm1637_5fwrite_5fbyte',['TM1637_write_byte',['../segmentanzeige_8c.html#a09f1e0171b38b9abbb5d351364cfec71',1,'TM1637_write_byte(byte wr_data):&#160;segmentanzeige.c'],['../TM1637__intern_8h.html#a09f1e0171b38b9abbb5d351364cfec71',1,'TM1637_write_byte(byte wr_data):&#160;segmentanzeige.c']]]
];
