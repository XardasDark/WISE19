var indexSectionsWithContent =
{
  0: "abdmnopst",
  1: "st",
  2: "t",
  3: "n",
  4: "bds",
  5: "bds",
  6: "bdmos",
  7: "abdps"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

