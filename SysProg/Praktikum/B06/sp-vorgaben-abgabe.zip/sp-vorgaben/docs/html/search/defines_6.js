var searchData=
[
  ['startaddr',['STARTADDR',['../ledanzeige_2TM1637_8c.html#a805760bafc4bcecc11a7039c07876252',1,'STARTADDR():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a805760bafc4bcecc11a7039c07876252',1,'STARTADDR():&#160;TM1637.c']]]
];
