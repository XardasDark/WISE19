var searchData=
[
  ['delete_5flist',['delete_list',['../studiverwaltung_8c.html#a5860871c54b561c01f84a3ea2a1bca7c',1,'delete_list(node *list):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#a5860871c54b561c01f84a3ea2a1bca7c',1,'delete_list(node *list):&#160;studiverwaltung.c']]],
  ['delete_5flist_5fpartial',['delete_list_partial',['../studiverwaltung_8c.html#a4850f89724c4df55b5b8a409c5de1745',1,'delete_list_partial(node *list):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#a4850f89724c4df55b5b8a409c5de1745',1,'delete_list_partial(node *list):&#160;studiverwaltung.c']]],
  ['delete_5fnode',['delete_node',['../studiverwaltung_8c.html#a8c5691065579a710c34e6b4871217613',1,'delete_node(node *nd, sp_purge purge):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#add60f71b17a8a93d7cbbadba95bccbda',1,'delete_node(node *node, sp_purge purge):&#160;studiverwaltung.c']]],
  ['display_5fabsolute',['display_absolute',['../pruefungen_8c.html#a410fe4cb6ddeadde9a4970a7ea218d7c',1,'display_absolute(void):&#160;pruefungen.c'],['../pruefungen_8h.html#a410fe4cb6ddeadde9a4970a7ea218d7c',1,'display_absolute(void):&#160;pruefungen.c']]],
  ['display_5faverage',['display_average',['../pruefungen_8c.html#acf9d4e9b5d28d837de9cf421ca02d64a',1,'display_average(void):&#160;pruefungen.c'],['../pruefungen_8h.html#acf9d4e9b5d28d837de9cf421ca02d64a',1,'display_average(void):&#160;pruefungen.c']]]
];
