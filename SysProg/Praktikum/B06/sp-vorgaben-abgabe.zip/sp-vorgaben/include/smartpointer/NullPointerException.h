//
// Created by chris on 16.12.2018.
//

#ifndef SP_VORGABEN_HANNES_NULLPOINTEREXCEPTION_H
#define SP_VORGABEN_HANNES_NULLPOINTEREXCEPTION_H

#include <exception>
#include <stdexcept>

/*
 * ===========================================================================
 * Implementation of class of Exception if one tries to dereference an
 * 'empty' SmartPointer
 * ===========================================================================
 */

class NullPointerException : public std::runtime_error {
public:
    NullPointerException() : std::runtime_error("NullPointerException occurred") {}

    virtual const char *what() const noexcept override {
        return "Tried to dereference an 'empty' SmartPointer.";
    }
};

#endif //SP_VORGABEN_HANNES_NULLPOINTEREXCEPTION_H
