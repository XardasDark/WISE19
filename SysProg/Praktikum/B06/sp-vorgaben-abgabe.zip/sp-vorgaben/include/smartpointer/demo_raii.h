/**
 * Darstellung des RAII-Idioms - Resource acquisition is initialization
*/

#ifndef RAII_H
#define RAII_H

#include <string>
#include <cstdio>
#include "smartpointer/SmartPointerImpl.h"


/**
 * Die Klasse, die mit dem RAII-Idiom verwirklicht wird
 */
class Datei {

public:
    /**
     * Konstruktor
     * @param name Referenz auf den Eingabestring
     */
    Datei(const std::string& name) : datei( std::fopen(name.c_str(), "w+") ) {
        if (datei == NULL) perror ("Datei konnte nicht geöffnet werden!");
    } //Öffnen der Datei im Konstruktor (RAII)

    /**
     * Destruktor
     */
    ~Datei() {
        std::fclose(datei); //Schließen der Datei im Destruktor (RAII)
    }

    /**
     * Methode, um in die Datei schreiben zu können
     * @param text Referenz auf den String, der in die Datei geschrieben werden soll
     */
    void schreiben(const std::string& text) {
        if (datei) {
            std::fputs(text.c_str(), datei);
        }
    }

private:
    FILE* datei;
};

void gebeMirDatei(std::string, SmartPointer<Datei>&);

#endif //RAII_H
