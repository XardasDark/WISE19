//
// Created by viddie on 16.12.18.
//

#ifndef SP_VORGABEN_SMARTPOINTERIMPL_H
#define SP_VORGABEN_SMARTPOINTERIMPL_H

#include <stdio.h>
#include <iostream>
#include "smartpointer/SmartPointer.h"
#include "smartpointer/RefCounter.h"
#include "smartpointer/NullPointerException.h"

/*
 * ===========================================================================
 * Implementation of class of Smartpointer
 * ===========================================================================
 */

using namespace std;

template<typename T>
SmartPointer<T>::SmartPointer(T *const p) {
    //std::cout << "Called constructor with 1 arg: p = " << p << std::endl;
    if (p == nullptr || p == NULL) {
        this->pObj = nullptr;
        this->rc = nullptr;
    } else {
        this->pObj = p;
        this->rc = new RefCounter();
        rc->inc();
    }
}

template<typename T>
SmartPointer<T>::SmartPointer(const SmartPointer &other) {
    //std::cout << "Called copy constructor" << std::endl;
    if (this != &other) {
        if (other.getObject() == nullptr || other.getObject() == NULL) {
            this->pObj = nullptr;
            this->rc = nullptr;
        } else {
            this->pObj = other.pObj;
            this->rc = other.rc;
            rc->inc();
        }
    }
}

template<typename T>
SmartPointer<T>::~SmartPointer() {
    deleteObject();
}

template<typename T>
T *SmartPointer<T>::operator->() const {
    if (pObj == nullptr) {
        throw NullPointerException();
    }
    return this->pObj;
}

template<typename T>
T &SmartPointer<T>::operator*() const {
    if (pObj == nullptr) {
        throw NullPointerException();
    }
    return *(this->pObj);
}

template<typename T>
const T *SmartPointer<T>::getObject() const {
    return this->pObj;
}

template<typename T>
const RefCounter *SmartPointer<T>::getRefCounter() const {
    return this->rc;
}

template<typename T>
const SmartPointer <T> &SmartPointer<T>::operator=(T *const p) {
    if (p == this->pObj) {
        return *this;
    }

    deleteObject();

    if (p == nullptr || p == NULL) {
        this->pObj = nullptr;
        this->rc = nullptr;
    } else {
        this->pObj = p;
        this->rc = new RefCounter();
        rc->inc();
    }
    return *this;
}

template<typename T>
const SmartPointer <T> &SmartPointer<T>::operator=(const SmartPointer &other) {
    if (this->pObj == other.pObj) {
        return *this;
    }

    deleteObject();


    if (other.pObj == nullptr || other.pObj == NULL) {
        this->pObj = nullptr;
        this->rc = nullptr;
    } else {
        this->pObj = other.pObj;
        this->rc = other.rc;
        this->rc->inc();
    }

    return *this;
}

template<typename T>
bool SmartPointer<T>::operator==(const SmartPointer &other) const {
    return this->pObj == other.pObj && this->rc == other.rc;
}

template<typename T>
bool SmartPointer<T>::operator!=(const SmartPointer &other) const {
    return !((*this) == other);
}

template<typename T>
SmartPointer<T>::operator bool() const {
    return this->pObj != nullptr;
}

template<typename T>
void SmartPointer<T>::deleteObject() {
    if (pObj != nullptr && pObj != NULL) {
        this->rc->dec();
        if (this->rc->isZero()) {
            delete this->pObj;
            delete this->rc;
            this->pObj = nullptr;
        }
    }
}

#endif //SP_VORGABEN_SMARTPOINTERIMPL_H
