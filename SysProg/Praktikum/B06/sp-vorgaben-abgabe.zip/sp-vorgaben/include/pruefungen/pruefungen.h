#ifndef SP_VORLAGEN_PRUEFUNGEN_H
#define SP_VORLAGEN_PRUEFUNGEN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "studiverwaltung/studiverwaltung.h"
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"

/* Maximal 320 CP sind erlaubt */
#define MAXIMUM_POINTS 320

/* Ein Array von Pointern auf Studenten die für die Prüfungen angemeldet sind */
student *exams[10];

/**
 * Registriert einen Studenten für die Prüfung
 * @param s der Student
 * @param nr die gewünschte Platznummer
 * @return -1 wenn der Student null ist oder bereits registriert, oder das array voll, ansonsten die vergebene Platznummer
 */
int register_student(student *s, int nr);

/**
 * Entfernt einen Studenten aus dem Register
 * @param s der Student
 * @return Gibt den Platz auf dem sich der Student befand zurück, oder -1 wenn nicht verfügbar
 */
int remove_student(student *s);

/**
 * @return Gibt den Durchschnittswert der CreditPoints aller angemeldeten Studenten als Prozentzahl von 0 bis 100 zurück
 */
float calculate_average(void);

/**
 * @return Gibt den Mittelwert auf dem PI aus
 */
void display_average(void);

/**
 * @return Gibt nacheinander für jeden Termin die Nummer und die Credits-Points des angemeldeten Studierenden auf dem PI aus
 */
void display_absolute(void);


#ifdef __cplusplus
}
#endif

#endif /*SP_VORLAGEN_PRUEFUNGEN_H*/
