//
// Created by viddie on 22.11.18.
//

#ifndef SP_VORGABEN_DISPLAY_H
#define SP_VORGABEN_DISPLAY_H

#ifdef __cplusplus
extern "C" {
#endif

    void display_heap(void);

#ifdef __cplusplus
}
#endif

#endif //SP_VORGABEN_DISPLAY_H
