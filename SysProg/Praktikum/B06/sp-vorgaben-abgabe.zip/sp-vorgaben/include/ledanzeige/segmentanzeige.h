#ifndef SEGMENTANZEIGE_H
#define SEGMENTANZEIGE_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * A datatype representing 8 bit, ie. a number from 0 to 255
 */
typedef unsigned char byte;

/**
 * An enum to represent the four parts of the segmented display.
 */
typedef enum segment {
    SEG1 = 0,
    SEG2 = 1,
    SEG3 = 2,
    SEG4 = 3
} segment;

/**
 * An enum to represent whether or not the dot should be enabled on the segmented display
 */
typedef enum dot {
    OFF = 0,
    ON = 1
} dot;

/**
 * An enum to represent the brightness of the segmented display
 */
typedef enum brightness {
    DARK = 0,
    MEDIUM = 1,
    BRIGHT = 7
} brightness;

#ifdef __cplusplus
}
#endif

#endif /* SEGMENTANZEIGE_H */
