#ifndef SQL_API_H
#define SQL_API_H

#include <sqlite3.h>
#include <string>

/**
 * Klasse Sql_api, die das Speichern in der Datenbank kapselt
 */
class Sql_api {
public:
    Sql_api(void);
    ~Sql_api(void);
    Sql_api(const Sql_api &a);
    Sql_api &operator=(const Sql_api &d);

    bool openDatabase(void);
    bool createTable(void);
    bool newEntry(std::string id, std::string time, std::string temperatureMinden, std::string temperatureInside);

private:
    sqlite3 *db;
    char *zErrMsg = 0;
    int rc;
    static int callback(void *NotUsed, int argc, char ** argv, char **azColName);
    std::string sql;
};

#endif //SQL_API_H