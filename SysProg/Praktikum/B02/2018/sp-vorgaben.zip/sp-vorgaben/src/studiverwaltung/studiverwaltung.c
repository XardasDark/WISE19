/**
 * studiverwaltung
 * @author ckrebel
 */

#include "studiverwaltung/studiverwaltung.h"
#include "studiverwaltung/spfree.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>


/**
 * Returns the starting node of a list
 * @param node a node of a list of which you want to have the head back
 * @return head of the list
 */
node *get_list_origin(node *node) {
    if (node == NULL) {
        return NULL;
    }
    while (node->prev != NULL) {
        node = node->prev;
    }
    return node;
}

/**
 * Returns the tail of a list
 * @param node a node of a list of which you want to have the tail back
 * @return tail of the list
 */
node *get_list_tail(node *node) {
    if (node == NULL) {
        return NULL;
    }
    while (node->next != NULL) {
        node = node->next;
    }
    return node;
}


/**
 * Appends a student to the end of a list
 * @param nd (head-)note of the list
 * @param stdnt student to append
 */
node *append_student(node *nd, student *stdnt) {

    if (!nd && !stdnt) {
        return NULL;
    }
    if (!stdnt) {
        return nd;
    }
    if (!nd) {

        nd = (node *) malloc(sizeof(node));
        if (!nd) {
            return NULL;
        }

        nd->prev = NULL;
        nd->next = NULL;
        nd->stdnt = stdnt;
        return nd;
    }

    while (nd->next) {
        nd = nd->next;
    }

    nd->next = (node *) malloc(sizeof(node));
    if (!nd->next) {
        return NULL;
    }
    nd->next->stdnt = stdnt;
    nd->next->prev = nd;
    nd->next->next = NULL;

    return get_list_origin(nd);
}


/**
 * Return a list with only IFM-students
 * @param head the (head-)node of a list which will be filtered
 * @return the new filtered list with only IFM-students
 */
node *get_ifm_students(node *head) {
    node *current;
    if (head == NULL) {
        return NULL;
    }
    head = get_list_origin(head);
    current = NULL;

    while (head != NULL) {
        if (head->stdnt->enrolled == IFM) {
            current = append_student(current, head->stdnt);
            if (!current) {
                return NULL;
            }
        }
        head = head->next;
    }
    return get_list_origin(current);
}

/**
 * Display a list nicely
 * @param head the (head-)node of the list to display
 */
void show_all(node *head) {
    node *tmp;
    head = get_list_origin(head);

    if (head == NULL) {
        printf("Die Liste ist leer.\n");
        return;
    }

    for (tmp = head; tmp; tmp = tmp->next) {
        char enroll[7];
        if (tmp->stdnt) {
            if (tmp->stdnt->enrolled == IFM) {
                strcpy(enroll, "IFM");
            } else if (tmp->stdnt->enrolled == ELM) {
                strcpy(enroll, "ELM");
            } else if (tmp->stdnt->enrolled == PFLEGE) {
                strcpy(enroll, "PFLEGE");
            }
            printf("%s, %s, %d\n", tmp->stdnt->name,
                   enroll, tmp->stdnt->cps);
        }
    }
}

/**
 * Deletes a node and frees its memory. Can als delete the
 * node's student if needed.
 * @param nd Node to delete
 * @param purge delete only node or also its student
 * @return the head of the deleted node's list
 */
node *delete_node(node *nd, sp_purge purge) {
    node *head = get_list_origin(nd);
    if (!nd) {
        return NULL;
    }
    if (nd->prev && nd->next) {
        nd->prev->next = nd->next;
        nd->next->prev = nd->prev;

        if (purge == NODE_AND_STUDENT) {
            free(nd->stdnt);
            nd->stdnt = NULL;
        }

        free(nd);

        return head;
    } else if (!nd->prev && nd->next) {
        nd->next->prev = NULL;
        head = nd->next;

        if (purge == NODE_AND_STUDENT) {
            free(nd->stdnt);
            nd->stdnt = NULL;
        }

        free(nd);

        return head;
    } else if (nd->prev && !nd->next) {
        nd->prev->next = NULL;

        if (purge == NODE_AND_STUDENT) {
            free(nd->stdnt);
            nd->stdnt = NULL;
        }

        free(nd);

        return head;
    } else {
        if (purge == NODE_AND_STUDENT) {
            free(nd->stdnt);
            nd->stdnt = NULL;
        }

        free(nd);

        return NULL;
    }

}

/**
 * Deletes an entire list with all students
 * @param list the list of nodes and students to be freed
 * @return how many nodes were freed
 */
int delete_list(node *list) {
    int count = 0;

    if (!list) {
        return 0;
    }

    list = get_list_tail(list);

    while (list->prev) {
        list = list->prev;
        delete_node(list->next, NODE_AND_STUDENT);

        count++;
    }

    delete_node(list, NODE_AND_STUDENT);


    return ++count;
}

/**
 * Delete all nodes of a list, but not the students in said list
 * @param list deletes all nodes in the list, but not the students
 * @return how many nodes were freed
 */
int delete_list_partial(node *list) {
    int count = 0;

    if (list == NULL) {
        return 0;
    }

    list = get_list_tail(list);

    while (list->prev) {
        list = list->prev;
        delete_node(list->next, NODE_ONLY);

        count++;
    }

    delete_node(list, NODE_ONLY);


    return ++count;
}
