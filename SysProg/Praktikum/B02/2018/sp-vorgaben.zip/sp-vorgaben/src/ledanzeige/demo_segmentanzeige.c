#include <stdio.h>
#include <wiringPi.h>
#include <unistd.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"

/**
 * Demo main to test the segmented display
 */
int main(){
	TM1637_setup();
	
	sleep(3);
	
	TM1637_display_number(999.9);
	sleep(2);

	TM1637_display_number(-99.9);
	sleep(2);
	
	TM1637_display_number(193.9);
	sleep(1);

	return 0;
}
