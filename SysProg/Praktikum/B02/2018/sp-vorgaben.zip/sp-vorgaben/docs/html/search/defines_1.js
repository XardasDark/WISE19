var searchData=
[
  ['bright_5foffset',['BRIGHT_OFFSET',['../ledanzeige_2TM1637_8c.html#a6c94edbcea161634d33b78aa6138f18a',1,'BRIGHT_OFFSET():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a6c94edbcea161634d33b78aa6138f18a',1,'BRIGHT_OFFSET():&#160;TM1637.c']]]
];
