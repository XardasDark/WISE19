var searchData=
[
  ['stdnt',['stdnt',['../structnode.html#a750b9a8e36bbed2dcf2b7c0a76320782',1,'node']]]
];
