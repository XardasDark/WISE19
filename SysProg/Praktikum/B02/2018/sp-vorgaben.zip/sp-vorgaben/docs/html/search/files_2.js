var searchData=
[
  ['segmentanzeige_2ec',['segmentanzeige.c',['../ledanzeige_2segmentanzeige_8c.html',1,'(Global Namespace)'],['../pruefungen_2segmentanzeige_8c.html',1,'(Global Namespace)']]],
  ['segmentanzeige_2eh',['segmentanzeige.h',['../segmentanzeige_8h.html',1,'']]],
  ['spfree_2eh',['spfree.h',['../spfree_8h.html',1,'']]],
  ['studiverwaltung_2ec',['studiverwaltung.c',['../studiverwaltung_8c.html',1,'']]],
  ['studiverwaltung_2ed',['studiverwaltung.d',['../studiverwaltung_8d.html',1,'']]],
  ['studiverwaltung_2eh',['studiverwaltung.h',['../studiverwaltung_8h.html',1,'']]]
];
