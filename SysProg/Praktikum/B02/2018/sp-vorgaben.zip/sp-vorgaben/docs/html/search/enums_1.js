var searchData=
[
  ['degree_5fprogram',['degree_program',['../studiverwaltung_8h.html#afea1a0808a440b8bfe966975b78f8ffd',1,'studiverwaltung.h']]],
  ['dot',['dot',['../segmentanzeige_8h.html#aab918c44be8d33ac19b291d5c1ad200c',1,'segmentanzeige.h']]]
];
