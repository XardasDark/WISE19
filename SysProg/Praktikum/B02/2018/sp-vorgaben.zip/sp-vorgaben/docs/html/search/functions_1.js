var searchData=
[
  ['calculate_5faverage',['calculate_average',['../pruefungen_8c.html#a81fab93118812838e30570c31f5d5bfc',1,'calculate_average(void):&#160;pruefungen.c'],['../pruefungen_8h.html#a81fab93118812838e30570c31f5d5bfc',1,'calculate_average(void):&#160;pruefungen.c']]]
];
