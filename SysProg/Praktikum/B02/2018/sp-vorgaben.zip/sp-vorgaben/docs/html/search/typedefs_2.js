var searchData=
[
  ['segment',['segment',['../segmentanzeige_8h.html#a554f46492b97458f1f72636445ac75b9',1,'segmentanzeige.h']]],
  ['student',['student',['../studiverwaltung_8h.html#a1d76714c211af344b38ff6b66552c8a9',1,'studiverwaltung.h']]]
];
