var searchData=
[
  ['pflege',['PFLEGE',['../studiverwaltung_8h.html#afea1a0808a440b8bfe966975b78f8ffdab404e342c4a9833fd4f4ee540f65491e',1,'studiverwaltung.h']]],
  ['pin_5fclock',['PIN_CLOCK',['../TM1637__intern_8h.html#a4f9c1d495d837d141f20242e1e35427f',1,'TM1637_intern.h']]],
  ['pin_5fdata',['PIN_DATA',['../TM1637__intern_8h.html#a573681f817f1ec4eca69d66cd687236d',1,'TM1637_intern.h']]],
  ['prev',['prev',['../structnode.html#a7ee3d227c728ce18a86e43ebc301046e',1,'node']]],
  ['pruefungen_2ec',['pruefungen.c',['../pruefungen_8c.html',1,'']]],
  ['pruefungen_2eh',['pruefungen.h',['../pruefungen_8h.html',1,'']]]
];
