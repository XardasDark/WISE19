var searchData=
[
  ['elm',['ELM',['../studiverwaltung_8h.html#afea1a0808a440b8bfe966975b78f8ffda4b26b52ee7a94b60ebd5764afe0004b0',1,'studiverwaltung.h']]],
  ['enrolled',['enrolled',['../structstudent.html#a7f9955d01d45a4f42cc0043b6523ce82',1,'student']]],
  ['exams',['exams',['../pruefungen_8h.html#a4835704296b5901e2c375d5b32333053',1,'pruefungen.h']]]
];
