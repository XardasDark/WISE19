var searchData=
[
  ['display_5fabsolute',['display_absolute',['../pruefungen_8c.html#a410fe4cb6ddeadde9a4970a7ea218d7c',1,'display_absolute(void):&#160;pruefungen.c'],['../pruefungen_8h.html#a410fe4cb6ddeadde9a4970a7ea218d7c',1,'display_absolute(void):&#160;pruefungen.c']]],
  ['display_5faverage',['display_average',['../pruefungen_8c.html#acf9d4e9b5d28d837de9cf421ca02d64a',1,'display_average(void):&#160;pruefungen.c'],['../pruefungen_8h.html#acf9d4e9b5d28d837de9cf421ca02d64a',1,'display_average(void):&#160;pruefungen.c']]]
];
