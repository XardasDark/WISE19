var searchData=
[
  ['show_5fall',['show_all',['../studiverwaltung_8c.html#a028366ba3ab2b5820f3210ea951ff841',1,'show_all(struct node *head):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#a028366ba3ab2b5820f3210ea951ff841',1,'show_all(struct node *head):&#160;studiverwaltung.c']]]
];
