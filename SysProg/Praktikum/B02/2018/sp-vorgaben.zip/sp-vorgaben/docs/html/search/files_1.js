var searchData=
[
  ['pruefungen_2ec',['pruefungen.c',['../pruefungen_8c.html',1,'']]],
  ['pruefungen_2eh',['pruefungen.h',['../pruefungen_8h.html',1,'']]]
];
