var searchData=
[
  ['main',['main',['../demo__segmentanzeige_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;demo_segmentanzeige.c'],['../demo__pruefungen_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;demo_pruefungen.c'],['../demo__studiverwaltung_8c.html#a6288eba0f8e8ad3ab1544ad731eb7667',1,'main(void):&#160;demo_studiverwaltung.c']]]
];
