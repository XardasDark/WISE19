var searchData=
[
  ['enrolled',['enrolled',['../structstudent.html#a7f9955d01d45a4f42cc0043b6523ce82',1,'student']]],
  ['exams',['exams',['../pruefungen_8h.html#a4835704296b5901e2c375d5b32333053',1,'pruefungen.h']]]
];
