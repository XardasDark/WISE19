var searchData=
[
  ['prev',['prev',['../structnode.html#a7ee3d227c728ce18a86e43ebc301046e',1,'node']]]
];
