var searchData=
[
  ['pin_5fclock',['PIN_CLOCK',['../TM1637__intern_8h.html#a4f9c1d495d837d141f20242e1e35427f',1,'TM1637_intern.h']]],
  ['pin_5fdata',['PIN_DATA',['../TM1637__intern_8h.html#a573681f817f1ec4eca69d66cd687236d',1,'TM1637_intern.h']]]
];
