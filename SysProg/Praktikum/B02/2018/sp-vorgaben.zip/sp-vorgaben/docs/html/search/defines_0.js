var searchData=
[
  ['addr_5fauto',['ADDR_AUTO',['../ledanzeige_2TM1637_8c.html#a2203b5992e4c754494b3f9930270b24e',1,'ADDR_AUTO():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a2203b5992e4c754494b3f9930270b24e',1,'ADDR_AUTO():&#160;TM1637.c']]],
  ['addr_5ffixed',['ADDR_FIXED',['../ledanzeige_2TM1637_8c.html#aeacf6083d07b1aa007687bd90a76dff6',1,'ADDR_FIXED():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#aeacf6083d07b1aa007687bd90a76dff6',1,'ADDR_FIXED():&#160;TM1637.c']]]
];
