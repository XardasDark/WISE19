var searchData=
[
  ['bright',['BRIGHT',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070a9e804722270243cbe874a5aa6785cb85',1,'segmentanzeige.h']]],
  ['bright_5foffset',['BRIGHT_OFFSET',['../ledanzeige_2TM1637_8c.html#a6c94edbcea161634d33b78aa6138f18a',1,'BRIGHT_OFFSET():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a6c94edbcea161634d33b78aa6138f18a',1,'BRIGHT_OFFSET():&#160;TM1637.c']]],
  ['brightness',['brightness',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070',1,'brightness():&#160;segmentanzeige.h'],['../segmentanzeige_8h.html#a21fbaf85b01621e4ca1ac11d6b1beb86',1,'brightness():&#160;segmentanzeige.h']]],
  ['byte',['byte',['../segmentanzeige_8h.html#a0c8186d9b9b7880309c27230bbb5e69d',1,'segmentanzeige.h']]]
];
