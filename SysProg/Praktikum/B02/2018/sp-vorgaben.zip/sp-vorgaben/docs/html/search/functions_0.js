var searchData=
[
  ['append_5fstudent',['append_student',['../studiverwaltung_8c.html#a159eaca82e0a8e6405ee53998f84bcd5',1,'append_student(struct node *node, student *stdnt):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#a159eaca82e0a8e6405ee53998f84bcd5',1,'append_student(struct node *node, student *stdnt):&#160;studiverwaltung.c']]]
];
