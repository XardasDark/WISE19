var searchData=
[
  ['name',['name',['../structstudent.html#aaf96ffe0cd3e94f06fc06f0680bd88d4',1,'student']]],
  ['name_5flength',['NAME_LENGTH',['../studiverwaltung_8h.html#af71324c57f05ff9e24bd384925dd6b17',1,'studiverwaltung.h']]],
  ['next',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]],
  ['node',['node',['../structnode.html',1,'']]],
  ['node_5fand_5fstudent',['NODE_AND_STUDENT',['../spfree_8h.html#a5267e1073fff9e2c32bb983a13cdf700ada9fdbf7869179433d87b04991df5c6f',1,'spfree.h']]],
  ['node_5fonly',['NODE_ONLY',['../spfree_8h.html#a5267e1073fff9e2c32bb983a13cdf700a72ac25ce577866414375d3cbbba54f70',1,'spfree.h']]],
  ['number_5fto_5fbyte',['NUMBER_TO_BYTE',['../ledanzeige_2TM1637_8c.html#a0dbeb7a4ce21d585502c227905f7b799',1,'NUMBER_TO_BYTE():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a0dbeb7a4ce21d585502c227905f7b799',1,'NUMBER_TO_BYTE():&#160;TM1637.c']]]
];
