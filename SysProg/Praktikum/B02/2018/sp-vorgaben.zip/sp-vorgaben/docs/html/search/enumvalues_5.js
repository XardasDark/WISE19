var searchData=
[
  ['node_5fand_5fstudent',['NODE_AND_STUDENT',['../spfree_8h.html#a5267e1073fff9e2c32bb983a13cdf700ada9fdbf7869179433d87b04991df5c6f',1,'spfree.h']]],
  ['node_5fonly',['NODE_ONLY',['../spfree_8h.html#a5267e1073fff9e2c32bb983a13cdf700a72ac25ce577866414375d3cbbba54f70',1,'spfree.h']]]
];
