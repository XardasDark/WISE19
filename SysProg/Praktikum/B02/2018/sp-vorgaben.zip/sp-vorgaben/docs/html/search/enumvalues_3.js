var searchData=
[
  ['ifm',['IFM',['../studiverwaltung_8h.html#afea1a0808a440b8bfe966975b78f8ffda96f06002d6cd80151b9c2ba997cdf624',1,'studiverwaltung.h']]]
];
