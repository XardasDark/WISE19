var searchData=
[
  ['dark',['DARK',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070a5564de0baf1f25257db17367eba68edd',1,'segmentanzeige.h']]],
  ['degree_5fprogram',['degree_program',['../studiverwaltung_8h.html#afea1a0808a440b8bfe966975b78f8ffd',1,'studiverwaltung.h']]],
  ['delay_5ftimer',['DELAY_TIMER',['../TM1637__intern_8h.html#a093fb58c584374660f2459896c024b91',1,'TM1637_intern.h']]],
  ['demo_5fpruefungen_2ec',['demo_pruefungen.c',['../demo__pruefungen_8c.html',1,'']]],
  ['demo_5fsegmentanzeige_2ec',['demo_segmentanzeige.c',['../demo__segmentanzeige_8c.html',1,'']]],
  ['demo_5fstudiverwaltung_2ec',['demo_studiverwaltung.c',['../demo__studiverwaltung_8c.html',1,'']]],
  ['demo_5fstudiverwaltung_2ed',['demo_studiverwaltung.d',['../demo__studiverwaltung_8d.html',1,'']]],
  ['display_5fabsolute',['display_absolute',['../pruefungen_8c.html#a410fe4cb6ddeadde9a4970a7ea218d7c',1,'display_absolute(void):&#160;pruefungen.c'],['../pruefungen_8h.html#a410fe4cb6ddeadde9a4970a7ea218d7c',1,'display_absolute(void):&#160;pruefungen.c']]],
  ['display_5faverage',['display_average',['../pruefungen_8c.html#acf9d4e9b5d28d837de9cf421ca02d64a',1,'display_average(void):&#160;pruefungen.c'],['../pruefungen_8h.html#acf9d4e9b5d28d837de9cf421ca02d64a',1,'display_average(void):&#160;pruefungen.c']]],
  ['dot',['dot',['../segmentanzeige_8h.html#aab918c44be8d33ac19b291d5c1ad200c',1,'dot():&#160;segmentanzeige.h'],['../segmentanzeige_8h.html#a84861830774b65edf459c4404f055c99',1,'dot():&#160;segmentanzeige.h']]],
  ['dot_5foffset',['DOT_OFFSET',['../ledanzeige_2TM1637_8c.html#a5143b48baa4639ec380d7a500e611d46',1,'DOT_OFFSET():&#160;TM1637.c'],['../pruefungen_2TM1637_8c.html#a5143b48baa4639ec380d7a500e611d46',1,'DOT_OFFSET():&#160;TM1637.c']]]
];
