var searchData=
[
  ['main',['main',['../demo__segmentanzeige_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;demo_segmentanzeige.c'],['../demo__pruefungen_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;demo_pruefungen.c'],['../demo__studiverwaltung_8c.html#a6288eba0f8e8ad3ab1544ad731eb7667',1,'main(void):&#160;demo_studiverwaltung.c']]],
  ['maximum_5fpoints',['MAXIMUM_POINTS',['../pruefungen_8h.html#a13979877af0ac84cb58dcda1e92dce13',1,'pruefungen.h']]],
  ['medium',['MEDIUM',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070a5340ec7ecef6cc3886684a3bd3450d64',1,'segmentanzeige.h']]]
];
