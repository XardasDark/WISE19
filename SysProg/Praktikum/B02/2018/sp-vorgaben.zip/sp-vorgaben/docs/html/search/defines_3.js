var searchData=
[
  ['maximum_5fpoints',['MAXIMUM_POINTS',['../pruefungen_8h.html#a13979877af0ac84cb58dcda1e92dce13',1,'pruefungen.h']]]
];
