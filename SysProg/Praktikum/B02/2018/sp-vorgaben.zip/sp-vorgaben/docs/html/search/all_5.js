var searchData=
[
  ['get_5fifm_5fstudents',['get_ifm_students',['../studiverwaltung_8c.html#a6bffa7d140def789cb975aef8a025065',1,'get_ifm_students(struct node *head):&#160;studiverwaltung.c'],['../studiverwaltung_8h.html#a6bffa7d140def789cb975aef8a025065',1,'get_ifm_students(struct node *head):&#160;studiverwaltung.c']]],
  ['get_5flist_5fhead',['get_list_head',['../studiverwaltung_8c.html#a36c12f9b7f2c9a8d5521b5019a9c5304',1,'studiverwaltung.c']]]
];
