var searchData=
[
  ['name_5flength',['NAME_LENGTH',['../studiverwaltung_8h.html#af71324c57f05ff9e24bd384925dd6b17',1,'studiverwaltung.h']]]
];
