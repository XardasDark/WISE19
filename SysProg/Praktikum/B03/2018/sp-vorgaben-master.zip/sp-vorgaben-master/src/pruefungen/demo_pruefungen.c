#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <wiringPi.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"
#include "pruefungen/pruefungen.h"


int main() {
    student *stud = (student *) malloc(sizeof(student));
    if (!stud) {
        printf("malloc failed for: *stud");
    }

    strcpy(stud->name, "TestStudent");
    stud->cps = 50;
    stud->enrolled = IFM;

    register_student(stud, 1);

    display_absolute();
    return 0;
}
