#include "studiverwaltung/studiverwaltung.h"

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

int main(void) {
    struct node *list, *ifm_list;
    student *studi1, *studi2, *studi3, *studi4, *studi5;

    printf("\n----- DEMO -----\n");

    printf("Create student Hannes\n");
    studi1 = (student *) malloc(sizeof(student));
    strcpy(studi1->name, "Hannes");
    studi1->cps = 60.0;
    studi1->enrolled = IFM;

    printf("Create student Dennis\n");
    studi2 = (student *) malloc(sizeof(student));
    strcpy(studi2->name, "Dennis");
    studi2->cps = 24.0;
    studi2->enrolled = PFLEGE;

    printf("Create student Chris\n");
    studi3 = (student *) malloc(sizeof(student));
    strcpy(studi3->name, "Chris");
    studi3->cps = 99.0;
    studi3->enrolled = IFM;

    printf("Create student Leon\n");
    studi4 = (student *) malloc(sizeof(student));
    strcpy(studi4->name, "Leon");
    studi4->cps = 300.0;
    studi4->enrolled = IFM;

    printf("Create student Joyce\n\n");
    studi5 = (student *) malloc(sizeof(student));
    strcpy(studi5->name, "Joyce");
    studi5->cps = 25.0;
    studi5->enrolled = ELM;

    printf("Create new list and add all students\n\n");
    list = append_student(NULL, studi1);
    list = append_student(list, studi2);
    list = append_student(list, studi3);
    list = append_student(list, studi4);
    list = append_student(list, studi5);


    printf("Show all:\n");
    show_all(list);
    printf("\nShow all IFM-students:\n");
    ifm_list = get_ifm_students(list);
    show_all(ifm_list);

    printf("\nDelete a node of the IFM list:\n");
    delete_node(ifm_list->next->next, NODE_ONLY);
    show_all(ifm_list);
    printf("\nShow all again:\n");
    show_all(list);

    printf("\nDelete a node of the IFM list and its student:\n");
    delete_node(ifm_list->next, NODE_AND_STUDENT);
    show_all(ifm_list);
    printf("\nShow all again:\n");
    show_all(list);

    printf("\nDelete the IFM list but not its students:\n");
    delete_list_partial(ifm_list);
    show_all(ifm_list);
    printf("\nShow all again:\n");
    show_all(list);

    printf("\nDelete the all-list and its students:\n");
    delete_list(list);
    show_all(list);

    return 0;
}