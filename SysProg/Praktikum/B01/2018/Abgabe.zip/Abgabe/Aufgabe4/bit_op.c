#include <math.h>
#include <stdio.h>

int checkBit();

int main(){
    checkBit(255, 6);

    return 0;
}

int checkBit(int numIn, int checkBitIndex){
    if(checkBitIndex < 0 || numIn < 0 || numIn > 255){
        return 0;
    }

    int actualBit = 1 << checkBitIndex;

    int isBitSet = numIn & actualBit;
    printf("Number: %d, Bit with index %d is set? -> %s\n", numIn, checkBitIndex, isBitSet ? "true" : "false");


    numIn = numIn | actualBit;
    printf("Number after setting the bit: %d\n", numIn);

    int invertedBitShort = ~actualBit;
    int invertedBit = 255 & invertedBitShort;
    numIn = numIn & invertedBit;
    printf("Number after unsetting the bit: %d\n", numIn);

    return isBitSet;
}