/*
 * Sinus functions
 */
#include <stdio.h>
#include <math.h>

#define M_PI 3.14159265358979323846

void sinWithFor();
	
void sinWithWhile();

int main() {
	printf("With For-loop:\n");
	sinWithFor();
	printf("\nWith While-loop:\n");
	sinWithWhile();
	return 0;
}

void sinWithFor() {
	float sine = 0;
	int i;
	for(i = 0; i <= 360; i += 10) {
		/*From degrees to radians*/
		sine = sin(i*M_PI/180);
		
		printf("Winkel: %3d Grad => Sinus-Funktionswert: %6.3lf\n", i, sine);
	}
}

void sinWithWhile() {
	float sine = 0;
	int i = 0;
	while(i <= 360) {
		/*From degrees to radians*/
		sine = sin(i*M_PI/180);
		
		printf("Winkel: %3d Grad => Sinus-Funktionswert: %6.3lf\n", i, sine);
		
		i += 10;
	}
}