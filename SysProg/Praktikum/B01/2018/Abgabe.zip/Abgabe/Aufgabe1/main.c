#include <stdio.h>

int main() {
    int a = -1;
    printf("Die groesstmoegliche unsigned int Zahl auf meinem System lautet: %u\n",a);
    return 0;
}