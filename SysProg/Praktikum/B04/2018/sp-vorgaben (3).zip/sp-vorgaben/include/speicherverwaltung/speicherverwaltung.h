//
// Created by chris on 18.11.2018.
//

#ifndef SP_VORGABEN_HANNES_SPEICHERVERWALTUNG_H
#define SP_VORGABEN_HANNES_SPEICHERVERWALTUNG_H

#include <stdlib.h>

#define MEM_POOL_SIZE 4096
#define MAGIC_INT 0xacdcacdc

#ifdef NDEBUG
#define  printDebug(expr)  printf("%s in '%s'[%d]: %s\n",  \
                                   __FILE__, __func__, \
                                   __LINE__, expr)
#else
#define printDebug(expr)  ;
#endif

#ifdef MALLOCSPLIT
#define SPLIT 1
#else
#define SPLIT 0
#endif


#ifdef __cplusplus
extern "C" {
#endif

    typedef struct memblock {
        size_t size;
        struct memblock *next;
        unsigned short id;
    } memblock;

    extern char mempool[MEM_POOL_SIZE];
    extern memblock *freemem;

    int cm_init(void);
    void* cm_malloc(size_t);
    void cm_free(void *);
    void cm_defrag(void);
    void *cm_memcpy(void *, const void *, size_t);
    void *cm_realloc(void *, size_t);


#ifdef __cplusplus
}
#endif

#endif //SP_VORGABEN_HANNES_SPEICHERVERWALTUNG_H
