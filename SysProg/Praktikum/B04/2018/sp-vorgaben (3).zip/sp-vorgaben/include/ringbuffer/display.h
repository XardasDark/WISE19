//
// Created by viddie on 28.11.18.
//

#ifndef DISPLAY_H
#define DISPLAY_H

#include "ringbuffer.h"

#ifdef __cplusplus
extern "C" {
#endif

    void display_status(const ring_buffer *);

#ifdef __cplusplus
}
#endif

#endif