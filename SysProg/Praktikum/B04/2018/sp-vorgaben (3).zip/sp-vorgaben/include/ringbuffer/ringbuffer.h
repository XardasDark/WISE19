//
// Created by Xardas Dark on 27.11.2018.
//
#include <stddef.h>
#ifndef SP_VORGABEN_RINGBUFFER_H
#define SP_VORGABEN_RINGBUFFER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ring_buffer
{
    size_t size, count, head; // size = Ringgröße, count = Anzahl Elemente, head = aktuelles Element
    void **elems; // dynamisches void* array
    void (*free_callback)(void *p); // Callback Function um Element aus dem Speicher zu entfernen
} ring_buffer;

//function declarations
ring_buffer *init_buffer(const size_t , void (*)(void *));
void *read_buffer(ring_buffer *);
void write_buffer(ring_buffer *, void *);
int free_buffer(ring_buffer *);
int count_elements(const ring_buffer *);

#ifdef __cplusplus
}
#endif

#endif //SP_VORGABEN_RINGBUFFER_H