//
// Created by viddie on 22.11.18.
//

#include <stdio.h>
#include <wiringPi.h>
#include <unistd.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"
#include "speicherverwaltung/display.h"
#include "speicherverwaltung/speicherverwaltung.h"

void display_heap(){

    int countBlocksAllocated = 0;
    int countBlocksFree = 0;
    size_t bytesUsed = 0;

    memblock *tmp_freemem = freemem;

    /*if(tmp_freemem != NULL){
        countBlocksFree++;
        while((tmp_freemem = tmp_freemem->next)){
            countBlocksFree++;
        }
    }*/

    tmp_freemem = (memblock *) mempool;
    do{
        if(tmp_freemem->next == (memblock *) MAGIC_INT){
            countBlocksAllocated++;
            bytesUsed += tmp_freemem->size + sizeof(memblock);
        }else{
            countBlocksFree++;
        }
        tmp_freemem = (memblock *)(((char *)(tmp_freemem + 1)) + tmp_freemem->size);
    }while((char *)tmp_freemem < mempool + MEM_POOL_SIZE);

    float percentUsed = (float) bytesUsed / (float) MEM_POOL_SIZE;

    char str[200];
    sprintf(str, "Total blocks: '%d' allocated blocks, '%d' free blocks, '%lu' bytes used (%.4f%%)", countBlocksAllocated, countBlocksFree, bytesUsed, percentUsed);
    printDebug(str);

    TM1637_setup();

    TM1637_display_number(countBlocksAllocated);
    sleep(2);

    TM1637_display_number(countBlocksFree);
    sleep(2);

    float displayBytes = 0.0;

    if(bytesUsed > 999.9){
        displayBytes = 999.9;
    }else{
        displayBytes = (float) bytesUsed;
    }

    TM1637_display_number(bytesUsed);
    sleep(2);

    TM1637_display_number(percentUsed);
    sleep(4);

    TM1637_clear_display();
}
