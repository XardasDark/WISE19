//
// Created by viddie on 18.11.18.
//

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include "speicherverwaltung/speicherverwaltung.h"

int main2(){


    char *char_ptr = (char *) cm_malloc(sizeof(char) * 20);
    if(char_ptr){
        printDebug("Pointer allocated.");
    }else{
        printDebug("Failed to allocate pointer.");
    }

    strcpy(char_ptr, "This char is long");

    char *ptr = (char *)(((memblock *)mempool) + 1);

    printDebug("First alloc:");
    printDebug(char_ptr);
    printDebug("Check:");
    printDebug(ptr);

    if(freemem){
        printDebug("Is freemem null? -> false");
    }else{
        printDebug("Is freemem null? -> true");
    }

    char *char_ptr2 = (char *) cm_malloc(sizeof(char) * 20);
    if(char_ptr2){
        printDebug("Pointer2 allocated.");
    }else{
        printDebug("Failed to allocate pointer2.");
    }

    char *char_ptr3 = (char *) cm_malloc(sizeof(char) * 20);
    if(char_ptr3){
        printDebug("Pointer3 allocated.");
    }else{
        printDebug("Failed to allocate pointer3.");
    }

    strcpy(char_ptr2, "Some other string");

    char *ptr2 = (char*)(((memblock *)mempool) + 1);
    ptr2 += 20;
    ptr2 += sizeof(memblock);

    printDebug("Second alloc:");
    printDebug(char_ptr2);
    printDebug("Check:");
    printDebug(ptr2);

    cm_free(char_ptr);
    cm_free(char_ptr2);
    cm_free(char_ptr3);

    return 0;
}
