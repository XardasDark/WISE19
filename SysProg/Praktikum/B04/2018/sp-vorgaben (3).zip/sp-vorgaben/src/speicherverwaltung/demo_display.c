//
// Created by viddie on 22.11.18.
//
#include <stdio.h>
#include <wiringPi.h>
#include <unistd.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"
#include "speicherverwaltung/display.h"
#include "speicherverwaltung/speicherverwaltung.h"


int main(){
    char *char_ptr = (char *) cm_malloc(sizeof(char) * 20);
    char *char_ptr2 = (char *) cm_malloc(sizeof(char) * 50);
    char *char_ptr3 = (char *) cm_malloc(sizeof(char) * 200);
    char *char_ptr4 = (char *) cm_malloc(sizeof(char) * 400);
    char *char_ptr5 = (char *) cm_malloc(sizeof(char) * 20);
    char *char_ptr6 = (char *) cm_malloc(sizeof(char) * 20);

    cm_free(char_ptr2);
    cm_free(char_ptr5);

    display_heap();


    return 0;
}
