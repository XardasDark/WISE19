//
// Created by viddie on 22.11.18.
//

#include <stdio.h>
#include <wiringPi.h>
#include <unistd.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"
#include "ringbuffer/display.h"
#include "ringbuffer/ringbuffer.h"

void display_status(const ring_buffer *cb){

    if(!cb){
       return;
    }

    //sprintf(str, "count: %u, size: %u", cb->count, cb->size);
    printf("count: %u, size: %u\n", cb->count, cb->size);

    float percentUsed = (float) cb->count / (float) cb->size;
    percentUsed *= 100;

    TM1637_setup();

    TM1637_display_number(percentUsed);
    sleep(4);

    TM1637_clear_display();
}
