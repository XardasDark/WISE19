/**
 * studiverwaltung header
 * @author ckrebel
 */

#ifndef SP_VORGABEN_STUDIVERWALTUNG_H
#define SP_VORGABEN_STUDIVERWALTUNG_H

#include "studiverwaltung/spfree.h"

#define NAME_LENGTH 12


#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    IFM,
    ELM,
    PFLEGE
} degree_program;

typedef struct {
    char name[NAME_LENGTH];
    unsigned short cps;
    degree_program enrolled;
} student;

typedef struct node {
    student *stdnt;
    struct node *next;
    struct node *prev;
} node;

node *get_ifm_students(node *head);

node *append_student(node *node, student *stdnt);

node *delete_node(node *node, sp_purge purge);

node *get_list_origin(node *node);

int delete_list(node *list);

int delete_list_partial(node *list);

int test(void);

void show_all(node *head);

#ifdef __cplusplus
}
#endif

#endif /*SP_VORGABEN_STUDIVERWALTUNG_H*/
