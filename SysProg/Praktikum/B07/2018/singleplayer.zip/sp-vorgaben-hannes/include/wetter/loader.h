//
// Created by chris on 13.12.2018.
//

#ifndef SP_VORGABEN_HANNES_LOADER_H
#define SP_VORGABEN_HANNES_LOADER_H

#include <curl/curl.h>
#include <string>

#define WEATHER_URL "http://api.openweathermap.org/data/2.5/weather?id=2871039&APPID=fab69c55c28c432a35fb4d56f8538007&mode=xml&units=metric"

#ifndef NDEBUG
#define printDebug(expr)  printf("%s in '%s'[%d]: %s\n",  \
                                   __FILE__, __func__, \
                                   __LINE__, expr)
#else
#define printDebug(expr)  ;
#endif

/**
 * Loads a website's content
 */
class loader {
public:
    loader(void);

    ~loader(void);

    loader(const loader &c);

    loader &operator=(const loader &z);

    void loadData(void);

    void printBuffer(void);
private:
    std::string buffer;

    static size_t f(char *data, size_t size, size_t nmemb, void *userdata);
};

#endif //SP_VORGABEN_HANNES_LOADER_H
