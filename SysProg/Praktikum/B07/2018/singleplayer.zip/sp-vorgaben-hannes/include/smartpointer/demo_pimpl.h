/**
 * Darstellung des PIMPL-Idioms - Pointer to implementation
*/

#ifndef PIMPL_H
#define PIMPL_H

#include "smartpointer/SmartPointerImpl.h"

class person
{
public:
    /**
     * Konstruktor
     * @param name, Name der person
     * @param id, id der person
     */
    person(std::string name, int id);

    /**
    * Copykonstruktor
    * @param person, ein Objekt von Person
    */
    person(const person &p);

    /**
     * Destruktor
     */
    ~person();



    /**
     * Eine Methode die den Namen einer Person ändert.
     * @param name der person
     */
    void setName(std::string name);

    /**
    * Eine Methode die den String der in Namen steht zurückgibt.
    *
    * @return wert der in name steht
    */
    std::string getName() const;

    /**
    * Eine Methode die den Wert von ID zurück gibt.
    *
    * @return wert der in id steht
    */
    int getId() const;
private:
    struct Impl;
    SmartPointer<Impl> pimpl;
};

#endif //PIMPL_H
