//
// Created by chris on 15.12.2018.
//


#include <stdio.h>
#include "smartpointer/RefCounter.h"

/*
 * ===========================================================================
 * Implementation of RefCounter
 * ===========================================================================
 */

/**
 * Default constructor
 */
RefCounter::RefCounter() {
    n = 0;
}

/**
 * Increment Counter n
 */
void RefCounter::inc() {
    n++;
}

/**
 * Decrement Counter n
 */
void RefCounter::dec() {
    if (!RefCounter::isZero()) {
        n--;
    }
}

/**
 * Check if Counter n is zero
 * @return true if n is 0, false if not
 */
bool RefCounter::isZero() const {
    return (n == 0) ? true : false;
}

/**
 * Get the Count n
 * @return n
 */
unsigned int RefCounter::getRefCount() const {
    return RefCounter::n;
}