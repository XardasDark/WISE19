//
// Created by chris on 03.01.2019.
//

#include "webserver/GUI.h"
#include "webserver/Game.h"
#include <ncurses.h>
#include <string>

using namespace std;

int main(int argv, char** argc) {
    int init_status = init();

    if(init_status == 0)
        run();

    close();

    return 0;
}