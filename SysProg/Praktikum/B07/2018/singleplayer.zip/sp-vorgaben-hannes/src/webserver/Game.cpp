//
// Created by chris on 03.01.2019.
//

#include <string>
#include <ncurses.h>
#include <unistd.h>
#include <locale.h>
#include <wchar.h>
#include <stdio.h>
#include <cstdint>
#include <vector>

#include "webserver/Game.h"

WINDOW* mainWnd;
WINDOW* gameWnd;

rect game_area;
rect screen_area;

vec2ui cur_size;

const int TERMINAL_WIDTH = 80;
const int TERMINAL_HEIGHT = 24;

int highScore = 0;

//char *chars = "^>v<";
        //{L"\x2191", L"\x2192", L"\x2193", L"\x2190"};

// The field
bool field[TERMINAL_WIDTH][TERMINAL_HEIGHT];

// The player
struct {
    vec2i pos;
    Direction dir;
    char disp_char;
    int currScore;
    int color;
} player;


int init() {

    srand(time(0));

    // ncurses init
    mainWnd = initscr();
    cbreak();
    noecho();
    clear();
    refresh();

    curs_set(0);

    start_color();

    // define window areas
    //
    screen_area = { { 0, 0 }, { TERMINAL_WIDTH, TERMINAL_HEIGHT } };
    gameWnd = newwin(  screen_area.height () - 2,
                        screen_area.width() - 2,
                        screen_area.top() + 1,
                        screen_area.left() + 1 );

    mainWnd = newwin(screen_area.height(), screen_area.width(), 0, 0);

    game_area = { { 0, 0 }, { screen_area.width() - 3, screen_area.height() - 3} };

    // useful color pairs
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    init_pair(2, COLOR_GREEN, COLOR_BLACK);
    init_pair(3, COLOR_YELLOW, COLOR_BLACK);
    init_pair(4, COLOR_RED, COLOR_BLACK);
    init_pair(5, COLOR_BLUE, COLOR_BLACK);
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(7, COLOR_CYAN, COLOR_BLACK);

    init_pair(8, COLOR_BLACK, COLOR_WHITE);

    // enable function keys
    keypad(mainWnd, true);
    keypad(gameWnd, true);

    // disable input blocking
    nodelay(mainWnd, true);
    nodelay(gameWnd, true);

    // color check
    if(!has_colors()) {
        endwin();
        printf("ERROR: Terminal does not support color.\n");
        exit(1);
    }

    // Background color for borders
    //wbkgd(mainWnd, COLOR_PAIR(6));

    return 0;
}

void changePlayerDir(bool rightPressed) {
    // change Direction
    if (player.dir == up && !rightPressed) {
            player.dir = left;
    } else if (player.dir == left && rightPressed) {
            player.dir = up;
    } else {
        if (rightPressed) {
            // Cast needed because enums cannot increment (without overriding an operator)
            player.dir = static_cast<Direction>(static_cast<int>(player.dir) + 1);
        } else {
            player.dir = static_cast<Direction>(static_cast<int>(player.dir) - 1);
        }
    }

    // Change Arrow-direction
    switch (player.dir) {
        case up:
            player.disp_char = '^';
            break;
        case right:
            player.disp_char = '>';
            break;
        case down:
            player.disp_char = 'v';
            break;
        case left:
            player.disp_char = '<';
            break;
        default:
            break;
    }
}



void run() {


    int tick;

    player.disp_char = 'v';
    player.dir = down;
    player.pos = {10, 5};
    player.currScore = 0;
    player.color = 3;

    int inChar = 0;
    bool gameOver = false;
    bool exitRequested = false;

    // draw frame around whole screen
    wattron(mainWnd, A_BOLD);
    box(mainWnd, 0, 0);
    wattroff(mainWnd, A_BOLD);

    // draw dividing line between game and stats (BUGGY!)
    wmove(mainWnd, game_area.bot() + 3, 1);
    //whline(mainWnd, '-', screen_area.width() - 2);
    for(int i = screen_area.left()+7; i < screen_area.right()-5; i+=2) {
        mvwprintw(mainWnd, 23, i, "-");
        mvwprintw(mainWnd, 0, i, "-");
    }

    // initial draw
    wrefresh(mainWnd);
    wrefresh(gameWnd);

    tick = 0;
    while(1) {

        // read inputs, lowercase all characters
        inChar = wgetch(mainWnd);
        inChar = tolower(inChar);

        vec2i posBefore = {player.pos.x, player.pos.y};

        Direction dirBefore = player.dir;

        bool keyPressed = false;

        switch(inChar) {
            case 'q':
                exitRequested = true;
                break;
            case KEY_LEFT:
                changePlayerDir(false);
                keyPressed = true;
                break;
            case KEY_RIGHT:
                changePlayerDir(true);
                keyPressed = true;
                break;
            default:
                break;
        }

        // Go in desired direction
        switch (player.dir) {
            case up:
                player.pos.y--;
                break;
            case right:
                player.pos.x++;
                break;
            case down:
                player.pos.y++;
                break;
            case left:
                player.pos.x--;
                break;
            default: break;
        }

        // GameOver?
        if(player.pos.x > game_area.right()
            || player.pos.x < game_area.left()
            || player.pos.y < game_area.top()
            || player.pos.y > game_area.bot()
            || field[player.pos.x][player.pos.y])
        {
         gameOver = true;
        }

        // Add players position to the field
        field[player.pos.x][player.pos.y] = true;

        // draw line on old position
        char line = '*';
        if(keyPressed) {
            if((dirBefore == down && player.dir == right)
                    || (dirBefore == down && player.dir == left)
                    || (dirBefore == left && player.dir == up)
                    || (dirBefore == right && player.dir == up)
                    )
            {
                line = '\'';
            } else {
                line = '.';
            }
        } else if(posBefore.x != player.pos.x) {
            line = '-';
        } else {
            line = '|';
        }
        wattron(gameWnd, COLOR_PAIR(player.color));
        mvwaddch(gameWnd, posBefore.y, posBefore.x, line);

        // draw new arrow char
        mvwaddch(gameWnd, player.pos.y, player.pos.x, player.disp_char);
        wattroff(gameWnd, COLOR_PAIR(player.color));

        player.currScore = tick;
        mvwprintw(mainWnd, 0, screen_area.left() + 3, " Score:%4d : Your High Score:%4d ", player.currScore, highScore);

        wrefresh(mainWnd);
        wrefresh(gameWnd);

        if(gameOver) {

            // Set High Score
            if(player.currScore > highScore) {
                highScore = player.currScore;
            }

            // store an approx location where text will be centered
            const int xpos = game_area.width() / 2 - 6;
            const int ypos = game_area.height() / 2 - 2;

            // erase current game content on window and redraw a clean window
            wclear(gameWnd);

            wrefresh(mainWnd);
            wrefresh(gameWnd);

            // print game over prompt
            mvwprintw(gameWnd, ypos, xpos , "GAME OVER");
            mvwprintw(gameWnd, ypos + 2, xpos - 8, "Press 'SPACE' to play again");
            mvwprintw(gameWnd, ypos + 4, xpos - 7, "Press 'q' to quit the game");

            // loop until player either quits or restarts game
            while(1) {
                inChar = wgetch(mainWnd);

                if(inChar == ' ') { // reset all variables and restart game
                    tick = 0;
                    player.pos = {10, 10};
                    player.currScore = 0;
                    inChar = 0;
                    gameOver = false;
                    exitRequested = false;
                    // reset field
                    for ( int i = 0; i < TERMINAL_WIDTH; i++ ) {
                        for (int j = 0; j < TERMINAL_HEIGHT; j++) {
                            field[i][j] = false;
                        }
                    }

                    wclear(gameWnd);
                    wrefresh(mainWnd);
                    wrefresh(gameWnd);
                    break;
                }

                else if(inChar == 'q') {
                    exitRequested = true;
                    break;
                }

                wrefresh(gameWnd);

                tick++;
                usleep(10000); // 1 ms
            }
        }

        if(exitRequested) break;

        tick++;
        // Delay
        //usleep(10000); // 10 ms
        usleep(100000);
        attroff(COLOR_PAIR(player.color));
    }
}

void close() {
    endwin();
}
