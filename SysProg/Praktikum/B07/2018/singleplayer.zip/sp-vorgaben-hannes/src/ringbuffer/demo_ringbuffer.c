//
// Created by Xardas Dark on 27.11.2018.
//
#include <stdlib.h>
#include <stdio.h>
#include "ringbuffer/ringbuffer.h"
#include "ringbuffer/display.h"

int main(int argc, char const *argv[]) {

    int **values = (int **) malloc(sizeof(int *) * 6);
    int count;
    for (count = 0; count <= 5; count++) {
        values[count] = (int *) malloc(sizeof(int));
        if (!values[count]) {
            printf("Fehler beim Heap reservieren\n");
            return 1;
        }
        *(values[count]) = count + 1;
        printf("%d\n", *(values[count]));
    }


    ring_buffer *rb = init_buffer(5, free);
    printf("Die Größe vom Ringbuffer: '%d'\n", (int) rb->size);

    for (count = 0; count < 5; count++) {
        write_buffer(rb, (void *) values[count]);
    }

    printf("Anzahl der Elemente: %d", count_elements(rb));
    printf("Vollen Fuellstand auf LED-Anzeige:");
    display_status(rb);

    printf("Ringbuffer mit Werten von 0 - 4 gefüllt\n");
    printf("Werte wieder aus dem Buffer holen\n");
    for (count = 0; count < 5; count++) {
        printf("%d\n", *((int *) read_buffer(rb)));
    }

    write_buffer(rb, (void *) values[0]);
    write_buffer(rb, (void *) values[1]);
    printf("40%% Fuellstand auf LED-Anzeige:");
    display_status(rb);

    read_buffer(rb);
    read_buffer(rb);


    printf("Erneut füllen\n");

    for (count = 0; count < 5; count++) {
        write_buffer(rb, (void *) values[count]);
    }

    printf("Mit Überlauf\n");
    write_buffer(rb, (void *) *(values + 5));

    printf("Werte wieder aus dem Buffer holen\n");
    for (count = 0; count < 5; count++) {
        printf("%d\n", *((int *) read_buffer(rb)));
    }

    printf("Leerer Fuellstand auf LED-Anzeige");
    display_status(rb);

    free_buffer(rb);

    return 0;
}
