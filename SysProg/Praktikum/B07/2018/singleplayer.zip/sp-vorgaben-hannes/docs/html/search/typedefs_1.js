var searchData=
[
  ['dot',['dot',['../segmentanzeige_8h.html#a84861830774b65edf459c4404f055c99',1,'segmentanzeige.h']]]
];
