var searchData=
[
  ['bright',['BRIGHT',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070a9e804722270243cbe874a5aa6785cb85',1,'segmentanzeige.h']]]
];
