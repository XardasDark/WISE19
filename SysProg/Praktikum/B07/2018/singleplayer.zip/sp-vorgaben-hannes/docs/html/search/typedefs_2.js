var searchData=
[
  ['segment',['segment',['../segmentanzeige_8h.html#a554f46492b97458f1f72636445ac75b9',1,'segmentanzeige.h']]]
];
