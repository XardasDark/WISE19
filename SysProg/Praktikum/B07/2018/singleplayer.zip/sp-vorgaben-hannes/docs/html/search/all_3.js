var searchData=
[
  ['medium',['MEDIUM',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070a5340ec7ecef6cc3886684a3bd3450d64',1,'segmentanzeige.h']]]
];
