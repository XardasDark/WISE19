var searchData=
[
  ['brightness',['brightness',['../segmentanzeige_8h.html#af3e3271e8fbc9f3863a2989d0105b070',1,'segmentanzeige.h']]]
];
