var searchData=
[
  ['off',['OFF',['../segmentanzeige_8h.html#aab918c44be8d33ac19b291d5c1ad200caac132f2982b98bcaa3445e535a03ff75',1,'segmentanzeige.h']]],
  ['on',['ON',['../segmentanzeige_8h.html#aab918c44be8d33ac19b291d5c1ad200ca977d478dacaae531f95695750d1e9d03',1,'segmentanzeige.h']]]
];
