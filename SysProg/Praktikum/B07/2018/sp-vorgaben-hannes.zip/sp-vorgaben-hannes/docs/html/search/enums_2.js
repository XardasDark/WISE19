var searchData=
[
  ['segment',['segment',['../segmentanzeige_8h.html#abd36269b836121415a7bc694fbe9fde7',1,'segmentanzeige.h']]]
];
