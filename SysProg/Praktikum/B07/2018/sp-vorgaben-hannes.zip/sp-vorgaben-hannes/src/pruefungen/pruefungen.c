#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <wiringPi.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"
#include "pruefungen/pruefungen.h"


/**
 * Fügt einen Studenten zu einem Termin hinzu
 * @param s Struktur Student
 * @param nr Integer Variable für die Termine Nummer 0-9
 * @return Integer Variable des erfolgreichen Termins, sonst Fehlerwert(-1)
 */
int register_student(student *s, int nr) {
    int i, x;
    /* Ist Student UND Platznummer kleiner 10 */
    if (s && nr < 10) {
        for (i = 0; i < 10; i++) {
            /* Wenn Student bereits auf der Liste gebe -1 aus*/
            if (exams[i] == s) {
                return -1;
            }
        }

        /* Versuche hinzuzufügen */
        for (i = 0; i < 10; i++) {
            x = (nr + i) % 10;

            if (x < 10) {
                if (exams[x] == NULL) {
                    exams[x] = s;
                    return x;
                }
            }

            x = nr - i;
            if (x >= 0) {
                if (exams[x] == NULL) {
                    exams[x] = s;
                    return x;
                }
            }
        }
    }
    return -1;
}

/**
 * Entfernt einen Student aus einem Termin
 * @param s Struktur Student
 * @return Integer Variable des entfernten Termins, sonst Fehlerwert(-1)
 */
int remove_student(student *s) {
    int i;
    /*Wenn Student vorhanden*/
    if (s) {
        /*Iteriere durch die Exam Liste*/
        for (i = 0; i < sizeof(exams); i++) {
            /*Wenn Student gefunden wurde*/
            if (exams[i] == s) {
                /*Exekutiere Student*/
                exams[i] = NULL;
                return i;
            }
        }
    }
    return -1;
}

/**
 * Berechnet den Durchschnitt der CPS von angemeldeten Studierenden
 * @return Float value in Prozent, wobei MAXIMUM_POINTS das Maximum ist
 */
float calculate_average(void) {
    float cps = 0;
    int anz = 0;
    student temp;
    int i;
    /* Gehe komplette Liste durch*/
    for (i = 0; i < sizeof(exams); i++) {
        /*Wenn Eintrag an dieser Stelle nicht NULL*/
        if (exams[i] != NULL) {
            /*Schreibe in temp den Wert dieser Adresse*/
            temp = *exams[i];
            /*Addiere die cps Studenten*/
            cps += temp.cps;
            anz++;
        }
    }
    cps /= anz;
    /* Gebe den Durchschnitt in Prozent an wobei 320 CPS = 100%*/
    return cps / MAXIMUM_POINTS * 100;
}

/**
 * Zeigt den Durchschnitt der CPS von angemeldeten Studierenden auf der LED-Anzeige an
 */
void display_average(void) {
    float cps = calculate_average();

    printf("CPS: %3.2f\n", cps);

    TM1637_setup();

    TM1637_display_number(cps);
    sleep(2);
    TM1637_clear_display();
}

/**
 * Zeigt nacheinander jeden Termin auf der LED-Anzeige an und die CPS des angemeldeten Studierenden
 */
void display_absolute(void) {
    student temp;
    int i;

    TM1637_setup();

    for (i = 0; i < (sizeof(exams) / sizeof(exams[0])); i++) {
        if (exams[i] != NULL) {
            temp = *exams[i];
            printf("Termin: %i\n", i);
            TM1637_display_number(i);
            sleep(2);
            printf("Student: %s CPS: %i\n", temp.name, temp.cps);
            TM1637_display_number(temp.cps);
            sleep(2);
        } else {
            TM1637_display_number(i);
            sleep(2);
            TM1637_display_number(-1);
            sleep(2);
        }
    }
    TM1637_clear_display();
}
