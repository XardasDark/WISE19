/**
 * Darstellung des RAII-Idioms
*/

#include <smartpointer/demo_raii.h>

#define DATEINAME1 "log.txt"
#define DATEINAME2 "log2.txt"


/**
 * Die Methode, um RAII zu demonstrieren
 *
 * @return Standardwert nach Durchlauf der Main-Funktion
 */
int main (void) {

    SmartPointer<Datei> ptr;
    gebeMirDatei(DATEINAME1, ptr);

    std::cout << "Schreiben in die Datei!" << std::endl;
    ptr->schreiben("Hallo Logfile 1!");


    std::cout << "Pointer zeigt auf andere Datei, dank Smartpointer und RAII kein Delete nötig!" << std::endl;
    gebeMirDatei(DATEINAME2, ptr);
    ptr->schreiben("Hallo Logfile 2!");

    return 0;
}

/**
 * Untermethode, um die Vorteile von RAII in verschiedenen Scopes zu zeigen
 *
 * @param dateiname Der Name der Datei, die geöffnet werden soll
 * @param ptr Der Pointer, der auf die geöffnete Datei zeigen soll
 * Durch diesen Pointer muss man sich nicht mehr, um die Speicherverwaltung der geöffneten Datei kümmern
 */
void gebeMirDatei(std::string dateiname, SmartPointer<Datei> &ptr) {
    std::cout << "Öffnen der Datei " << dateiname <<" in irgendeiner Methode!" << std::endl;
    Datei *datei = new Datei(dateiname);
    ptr = datei;
}

