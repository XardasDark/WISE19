
#include <stdio.h>
#include <wiringPi.h>
#include "ledanzeige/TM1637.h"
#include "ledanzeige/TM1637_intern.h"
#include "ledanzeige/segmentanzeige.h"

/**
 * Writes a byte of data to the segmented display
 * @param wr_data the byte to be written to the display
 */
void TM1637_write_byte(byte wr_data) {
    int bit;
    for (bit = 0; bit < 8; bit++) {
        digitalWrite(PIN_CLOCK, LOW);
        delayMicroseconds(DELAY_TIMER);

        if (((1 << bit) & wr_data) == (1 << bit)) {
            digitalWrite(PIN_DATA, HIGH);
        } else {
            digitalWrite(PIN_DATA, LOW);
        }
        delayMicroseconds(DELAY_TIMER);

        digitalWrite(PIN_CLOCK, HIGH);
        delayMicroseconds(DELAY_TIMER);
    }

    TM1637_ack();
}

