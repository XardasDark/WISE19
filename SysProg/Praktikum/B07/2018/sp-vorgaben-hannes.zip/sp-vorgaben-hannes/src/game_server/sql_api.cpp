/**
 * Die Definition der Klasse Sql_api, um die Daten in der Datenbank abzulegen
*/

#include <sqlite3.h>
#include "temperatur/sql_api.h"
#include <iostream>


/**
 * Standardkonstruktor der Klasse Sql_api
 */
Sql_api::Sql_api() {
    openDatabase();
    createTable();
}

/**
 * Destruktor der Klasse Sql_api, schließt Verbindung zur Datenbank
 */
Sql_api::~Sql_api() {
    sqlite3_close(db);
}

/**
 * Copy-Konstruktor
 *
 * @param a Ist die Klasse Sql_api, die kopiert werden soll
 */
Sql_api::Sql_api(const Sql_api &a) {
    db = a.db;
    zErrMsg = a.zErrMsg;
    rc = a.rc;
    sql = a.sql;
}

/**
 * Zuweisungsoperator
 *
 * @param d Ist die Klasse Sql_api, die THIS gleichgesetzt werden soll
 * @return Eine Referenz auf sich selbst
 */
Sql_api& Sql_api::operator=(const Sql_api &d) {
    if(this != &d) {
        db = d.db;
        zErrMsg = d.zErrMsg;
        rc = d.rc;
        sql = d.sql;
    }
    return *this;
}

/**
 * Die Callback-Funktion für sql-Lite
 *
 * @return Returned standardmäig Null
 */
int Sql_api::callback(void *NotUsed, int argc, char **argv, char **azColName) {
    return 0;
}

/**
 * Ã–ffnet eine Verbindung zur Datenbank, wenn Datei weather.db nicht vorhanden ist, wird diese erstellt
 * @return True oder False, je nachdem, ob das Öffnen erfolgreich war
 */
bool Sql_api::openDatabase() {
    rc = sqlite3_open("corner_fever.db", &db);
    if(rc) {
        return false;
    } else {
        return true;
    }
}

/**
 * Tabelle in der Datenbank wird erzeugt. Ist nur erfolgreich, wenn die Tabelle noch nicht existiert.
 * Wenn Tabelle schon existiert, hat SQL-Statement keine Wirkung.
 *
 * @return True oder False, je nachdem, ob das Erstellen erfolgreich war
 */
bool Sql_api::createTable() {
    if(rc) {
        return false;
    }

    sql = "CREATE TABLE IF NOT EXISTS GAME_INFO(" \
		  "ID INTEGER PRIMARY KEY NOT NULL," \
		  "TIME CHAR(30) NOT NULL," \
		  "PARTICIPANTS CHAR(1024) NOT NULL," \
		  "SCORES CHAR(1024) NOT NULL );";

    rc = sqlite3_exec(db, sql.c_str(), callback, 0, &zErrMsg);

    if(rc != SQLITE_OK) {
        sqlite3_free(zErrMsg);
        return false;
    }
    return true;
}

/**
 * Neuer Eintrag/Zeile wird in der Datenbank gespeichert
 *
 * @param id Die ID der neuen Zeile
 * @param time Der Zeitstempel der neuen Zeile
 * @param temperatureMinden Die Temperatur in Minden
 * @param temperatureInside Die Temperatur im Raum
 * @return True oder False, je nachdem, ob das Einfügen des Eintrags erfolgreich war
 */
bool Sql_api::newEntry(int id, const char *time, const char *participants, const char *scores) {

    char buff[4096];
    sprintf(buff, "INSERT INTO TEMPERATURES (ID, TIME, PARTICIPANTS, SCORES) VALUES (%d, '%s', '%s', '%s')", id, time, participants, scores);

    //sql = "INSERT INTO TEMPERATURES (ID, TIME, TEMPERATUREMINDEN, TEMPERATUREINSIDE)" \
	//	  "VALUES(" + id + ", '" + time + "', '" + participants + "', '" + scores + "');";
    rc = sqlite3_exec(db, buff, callback, 0, &zErrMsg);

    if(rc != SQLITE_OK) {
        sqlite3_free(zErrMsg);
        return false;
    }
    return true;
}
