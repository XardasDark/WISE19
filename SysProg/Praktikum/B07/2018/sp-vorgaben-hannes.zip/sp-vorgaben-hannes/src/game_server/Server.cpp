//
// Created by viddie on 14.01.19.
//

#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <fcntl.h>
#include <cerrno>
#include <algorithm>
#include <map>
#include <signal.h>
#include <ctime>
#include <syslog.h>
#include <wiringPi.h>

#include "game/Game.h"
#include "temperatur/sql_api.h"
#include "temperatur/calcTemp.h"
#include "temperatur/tempSensor.h"
#include "ledanzeige/TM1637.h"

#define TICKS_PER_SECOND 5
#define LOBBY_SIZE 3

using namespace std;

// Socket variables
int serverSocketFD;
struct sockaddr_in address;
int addrlen;

// Window variables
rect screen_area;
rect game_area;

// Game variables
vector<int> clients;
map<int, player_t> clientsToPlayers;
cell field[TERMINAL_WIDTH][TERMINAL_HEIGHT];
int ticksPerSecond = TICKS_PER_SECOND;
int lobbySize;
int playersAlive;

map<int, char*> colorStrings;
//0 = playercount, 1 = playersAlive, 2 = scoreOfPlayer, 3 =  tickCount
int ledOutType = 0;
int selectedClient = -1;
TempSensor tempSens(calculateTemperature);

void serverInit(void);
void runServer(void);
void onExit(void);
void initGame(void);

void setReuseAddrAndPort(int);
void setNonBlockingMode(int);
void bindSocket(int);
void setListenMode(int);

int safeRead(int, void*, size_t);
void closeConnectionToClient(int);
void processTickForClient(int);
void changePlayerDirection(player_t &, bool);

void handle_sighup(int);
void handle_sigusr(int);
void handle_sigterm(int);
void handle_sigint(int);
void handle_sigchld(int);
void handle_signal(int);

void tick_led_callback(void);
void tick_temp_callback(void);

int main(int argc, char const *argv[]){


    openlog("[CORNER-FEVER_Server]: ", LOG_PID, LOG_USER);

    syslog(LOG_INFO, "Initializing LED-Display...");
    TM1637_setup();
    syslog(LOG_INFO, "LED-Display initialized!");

    syslog(LOG_INFO, "Starting server...");



    signal(SIGHUP, handle_signal);
    signal(SIGUSR1, handle_signal);
    signal(SIGUSR2, handle_signal);
    signal(SIGTERM, handle_signal);
    signal(SIGINT, handle_signal);
    signal(SIGCHLD, handle_signal);


    colorStrings[1] = "WHITE";
    colorStrings[2] = "GREEN";
    colorStrings[3] = "YELLOW";
    colorStrings[4] = "RED";
    colorStrings[5] = "BLUE";
    colorStrings[6] = "PINKY";
    colorStrings[7] = "CYAN";

    serverInit();
    runServer();
    onExit();

    return 0;
}

void handle_signal(int signal){
    syslog(LOG_INFO, "Handling signal '%d'", signal);

    sigset_t blocked;
    sigemptyset(&blocked);

    sigaddset(&blocked, SIGHUP);
    sigaddset(&blocked, SIGUSR1);
    sigaddset(&blocked, SIGUSR2);
    sigaddset(&blocked, SIGTERM);
    sigaddset(&blocked, SIGINT);
    sigaddset(&blocked, SIGCHLD);

    sigprocmask(SIG_BLOCK, &blocked, NULL);

    if(signal == SIGHUP){
        handle_sighup(signal);

    }else if(signal == SIGUSR1 || signal == SIGUSR2){
        handle_sigusr(signal);

    }else if(signal == SIGTERM){
        handle_sigterm(signal);

    }else if(signal == SIGINT){
        handle_sigint(signal);

    }else if(signal == SIGCHLD){
        handle_sigchld(signal);
    }

    sigprocmask(SIG_UNBLOCK, &blocked, NULL);
}

void handle_sighup(int signal){
    // Der Aufbau des Spielfeldes ist doch sowieso fest... was soll hier gemacht werden?
    printf("Reprocessing playing field...\n");
    syslog(LOG_INFO, "Reprocessing playing field...\n");
}

void handle_sigusr(int signal){
    if(signal == SIGUSR1){
        printf("Increased ticksPerSecond to '%d'\n", ticksPerSecond);
        syslog(LOG_INFO, "Increased ticksPerSecond to '%d'\n", ticksPerSecond);
        ticksPerSecond++;
    }else{
        ticksPerSecond--;
        if(ticksPerSecond == 0){
            ticksPerSecond = 1;
            printf("You can't decrease the ticksPerSecond past 1!\n");
            syslog(LOG_INFO, "You can't decrease the ticksPerSecond past 1!\n");
        }else{
            printf("Decreased ticksPerSecond to '%d'\n", ticksPerSecond);
            syslog(LOG_INFO, "Decreased ticksPerSecond to '%d'\n", ticksPerSecond);
        }
    }
}

void handle_sigterm(int signal){
    printf("Saving information to database...\n");
    syslog(LOG_INFO, "Saving information to database...\n");
    Sql_api dbConnection;

    string participants;
    string scores;

    for(auto const &clientSocketFD : clients){
        player_t player = clientsToPlayers[clientSocketFD];
        participants += colorStrings[player.color];
        participants += ", ";

        scores += player.currScore;
        scores += ", ";
    }

    time_t rawtime;
    struct tm * timeinfo;
    char buffer[80];

    time (&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(buffer,sizeof(buffer),"%d-%m-%Y %H:%M:%S",timeinfo);
    string timeStr(buffer);

    dbConnection.newEntry(1, timeStr.c_str(), participants.c_str(), scores.c_str());

    printf("Saved information to database!\nNotifying clients...\n");
    syslog(LOG_INFO, "Saved to database! Notifying clients...");

    for(auto const &clientSocketFD : clients){
        closeConnectionToClient(clientSocketFD);
    }

    printf("Notified clients! Exiting application...\n");
    syslog(LOG_INFO, "Notifed clients! Exiting application...");

    onExit();
}

void handle_sigint(int signal){
    selectedClient = (selectedClient + 1) % clients.size();
    syslog(LOG_INFO, "Changed score shown on LED-Display to client '%s'", colorStrings[clientsToPlayers[clients[selectedClient]].color]);
}

void handle_sigchld(int signal){
    ledOutType = (ledOutType + 1) % 4;

    string type;

    if(ledOutType == 0){
        type = "Player count";
    }else if(ledOutType == 1){
        type = "Players alive";
    }else if(ledOutType == 2){
        type = "Points of player";
    }else if(ledOutType == 3){
        type = "Ticks per second";
    }

    syslog(LOG_INFO, "Changed LED-Display type to '%s'", type);
}

void tick_led_callback(){

    if(ledOutType == 0){
        TM1637_display_number(clients.size());

    }else if(ledOutType == 1){
        TM1637_display_number(playersAlive);

    }else if(ledOutType == 2){
        if(selectedClient != -1){
            int scoreToSet = clientsToPlayers[clients[selectedClient]].currScore;
            TM1637_display_number(scoreToSet);
            syslog(LOG_INFO, "Score of player '%s' = %d", colorStrings[clientsToPlayers[clients[selectedClient]].color], scoreToSet);
        }

    }else if(ledOutType == 3){
        TM1637_display_number(ticksPerSecond);
    }
}

void tick_temp_callback(){
    float temperature = tempSens.getTemp();
    int tempCut = (int) temperature;
    int defaultTick = TICKS_PER_SECOND;
    int actualTick = max(defaultTick + tempCut - 20, 1);

    if(ticksPerSecond != actualTick){
        syslog(LOG_INFO, "Changing temperature -> Changing ticksPerSecond by %d", (ticksPerSecond - actualTick));
    }

    ticksPerSecond = actualTick;

}

void serverInit(){
    serverSocketFD = socket(AF_INET, SOCK_STREAM, 0);

    if(!serverSocketFD){
        syslog(LOG_INFO, "Failed to construct socket.");
        exit(EXIT_FAILURE);
    }

    setReuseAddrAndPort(serverSocketFD);
    setNonBlockingMode(serverSocketFD);


    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    addrlen = sizeof(address);

    bindSocket(serverSocketFD);
    setListenMode(serverSocketFD);


    lobbySize = min(LOBBY_SIZE, 7);

    syslog(LOG_INFO, "Server is up and running!");
}

void runServer(){
    //Start lobby phase, waiting for players

    bool inProgress = false;

    while(1){
        int newSocket = accept(serverSocketFD, (struct sockaddr *) &address, (socklen_t *) &addrlen);
        if(newSocket < 0){
            //Do nothing, non-blocking sockets will execute this very often
        }else{
            //Once a connection has been accepted successfully
            syslog(LOG_INFO, "Accepted new connection...");
            LobbyError retError;

            if(clients.size() >= lobbySize || inProgress){
                if(clients.size() >= LOBBY_SIZE){
                    retError = LobbyError_LOBBY_FULL;
                    syslog(LOG_INFO, "...but closed it due to the lobby being full. (%d/%d)", lobbySize, lobbySize);
                }else if(inProgress){
                    retError = LobbyError_LOBBY_IN_PROGRESS;
                    syslog(LOG_INFO, "...but closed it due to the lobby being already in progress.");
                }
                write(newSocket, &retError, sizeof(retError));
                close(newSocket);
                continue;

            }

            retError = LobbyError_OK;
            clients.push_back(newSocket);

            setNonBlockingMode(newSocket);

            write(newSocket, &retError, sizeof(retError));


            syslog(LOG_INFO, "...and sent lobby information!");
            //printf("Accepted new connection and sent lobby details.\n");
        }



        //
        // GAME IN PROGRESS
        //
        if(inProgress){
            //Process each clients tick individually
            for(auto const &clientSocketFD : clients){
                //printf("Processing tick for player '%d'\n", clientsToPlayers[clientSocketFD].color);
                processTickForClient(clientSocketFD);
            }


            for(auto const &clientSocketFD : clients){
                // Send updated version of scoreboard
                for(auto const &client : clients){
                    player_t player = clientsToPlayers[client];
                    write(clientSocketFD, &player, sizeof(player));
                }

                write(clientSocketFD, field, sizeof(field));
            }

            if(playersAlive == 0){
                // Handle game-over, switch to lobby phase
                syslog(LOG_INFO, "All players died!");
                //printf("All players died!\n");
                inProgress = false;
            }


            tick_led_callback();
            tick_temp_callback();

        //
        // LOBBY PHASE
        //
        }else{
            for(auto const &clientSocketFD : clients){
                ServerCommand cmd = ServerCommand_NONE;

                //Reading from all clients, waiting for START_GAME command from one of them.
                int err = safeRead(clientSocketFD, &cmd, sizeof(cmd));

                if(err < 0){
                    if(errno != EAGAIN && errno != EWOULDBLOCK){
                        syslog(LOG_INFO, "Encountered error while reading from client: errno(%d) - %s", errno, strerror(errno));
                        //printf("Encountered error while reading from client: errno(%d) - %s\n", errno, strerror(errno));
                        closeConnectionToClient(clientSocketFD);
                    }

                }else if(err == 0){
                    closeConnectionToClient(clientSocketFD);
                }

                if(cmd == ServerCommand_START_GAME){
                    syslog(LOG_INFO, "Received command to start the game from client!");
                    //printf("Starting game\n");
                    //Notify other clients of game start
                    for(auto const &otherClient : clients){
                        if(otherClient != clientSocketFD){
                            ServerCommand startCommand = ServerCommand_START_GAME;
                            write(otherClient, &startCommand, sizeof(startCommand));
                        }
                    }

                    initGame();
                    inProgress = true;

                }else if(cmd == ServerCommand_LEAVE_GAME){
                    syslog(LOG_INFO, "Client '%d' left the game!", clientSocketFD);
                    //printf("Client '%d' left the game!\n", clientSocketFD);
                    closeConnectionToClient(clientSocketFD);

                }else if(cmd == ServerCommand_NONE){
                    //Client did not send anything

                }else{
                    syslog(LOG_INFO, "Received unusual cmd");
                }
            }
        }

        usleep((unsigned int) (1000000 / ticksPerSecond));
    }
}

void initGame(){

    screen_area = { { 0, 0 }, { TERMINAL_WIDTH, TERMINAL_HEIGHT } };
    game_area = { { 0, 0 }, { screen_area.width() - 3, screen_area.height() - 3} };

    //Init player positions, colors, map colors/player objects to clientSocketFD's
    //Send that info to all clients

    int playerCount = clients.size();
    playersAlive = playerCount;

    int i = 0;

    for(auto const &clientSocketFD : clients){
        player_t player;
        player.pos = { (((TERMINAL_WIDTH - 10) / playerCount) * i) + 5, 4};
        player.dir = down;
        player.disp_char = 'v';
        player.currScore = 0;
        player.color = i+1;

        //printf("Starting player %d: x: %d, y: %d, dir: down, disp_char = v, score: 0, color: %d\n", clientSocketFD, player.pos.x, player.pos.y, player.color);

        clientsToPlayers[clientSocketFD] = player;

        i++;
    }

    for(auto const &clientSocketFD : clients){
        //printf("Sending init info to client %d\n", clientSocketFD);
        player_t ownPlayer = clientsToPlayers[clientSocketFD];
        write(clientSocketFD, &playerCount, sizeof(playerCount));
        write(clientSocketFD, &ownPlayer.color, sizeof(ownPlayer.color));

        for(auto const &otherClient : clients){
            player_t otherPlayer = clientsToPlayers[otherClient];
            write(clientSocketFD, &otherPlayer, sizeof(otherPlayer));
        }
    }

    for ( int i = 0; i < TERMINAL_WIDTH; i++ ) {
        for (int j = 0; j < TERMINAL_HEIGHT; j++) {
            field[i][j] = { (char) 0, -1 };
        }
    }


}

void processTickForClient(int clientSocketFD){

    player_t player = clientsToPlayers[clientSocketFD];

    if(player.disp_char == 'X') {
        return;
    } else {

    }


    vec2i posBefore = {player.pos.x, player.pos.y};
    Direction dirBefore = player.dir;

    bool skipMove = false;


    GameCommand cmd = GameCommand_NONE;
    int err = safeRead(clientSocketFD, &cmd, sizeof(cmd));

    if(err < 0){
        if(errno != EAGAIN && errno != EWOULDBLOCK){
            syslog(LOG_INFO, "Encountered error while reading from client: errno(%d) - %s", errno, strerror(errno));

            //At this stage we are already ingame, so this client's player needs to be killed

            player.disp_char = 'X';
            skipMove = true;

            closeConnectionToClient(clientSocketFD);

            //printf("Client '%d' lost connection!\n", player.color);
        }
    }else if(err == 0){
        syslog(LOG_INFO, "Client '%d' lost connection to the server!", clientSocketFD);
        closeConnectionToClient(clientSocketFD);
        player.disp_char = 'X';
        skipMove = true;
    }

    //
    // Determine desired direction
    //

    bool hadInput = true;
    bool rightPressed;

    if(cmd != GameCommand_NONE){

        if(cmd == GameCommand_LEFT){
            rightPressed = false;
            syslog(LOG_INFO, "Client '%d' issued the comand to turn left", clientSocketFD);

        } else if (cmd == GameCommand_RIGHT){
            rightPressed = true;
            syslog(LOG_INFO, "Client '%d' issued the comand to turn right", clientSocketFD);

        } else if (cmd == GameCommand_LEAVE_GAME){
            player.disp_char = 'X';
            skipMove = true;

            closeConnectionToClient(clientSocketFD);

            syslog(LOG_INFO, "Client '%d' disconnected!", player.color);
        }

    } else {
        hadInput = false;
    }

    //
    // Move player in desired direction
    //

    if(!skipMove){

        //Change direction
        if(hadInput){
            changePlayerDirection(player, rightPressed);
        }

        vec2i newPos { player.pos.x, player.pos.y };

        // Advance player
        switch (player.dir) {
            case up:
                newPos.y--;
                break;
            case right:
                newPos.x++;
                break;
            case down:
                newPos.y++;
                break;
            case left:
                newPos.x--;
                break;
            default: break;
        }

        // Check for game-over
        if(newPos.x > game_area.right()
           || newPos.x < game_area.left()
           || newPos.y < game_area.top()
           || newPos.y > game_area.bot()
           || field[newPos.x][newPos.y].disp_char != (char) 0)
        {
            player.disp_char = 'X';

        } else {
            player.pos.x = newPos.x;
            player.pos.y = newPos.y;
        }
    }


    // Determine new character to draw to the field
    char line = '*';
    if(player.disp_char != 'X'){

        if(hadInput){

            if((dirBefore == down && player.dir == right)
               || (dirBefore == down && player.dir == left)
               || (dirBefore == left && player.dir == up)
               || (dirBefore == right && player.dir == up))
            {
                line = '\'';
            } else {
                line = '.';
            }

        } else {
            if(posBefore.x != player.pos.x) {
                line = '-';
            } else {
                line = '|';
            }
        }

    } else{
        line = 'X';
        playersAlive--;
        //printf("Player '%d' died! -> '%c'\n", player.color, player.disp_char);
    }

    // Insert character into field
    field[posBefore.x][posBefore.y].disp_char = line;
    field[posBefore.x][posBefore.y].color = player.color;

    if(line != 'X'){
        field[player.pos.x][player.pos.y].disp_char = player.disp_char;
        field[player.pos.x][player.pos.y].color = player.color;
    }


    player.currScore++;

    clientsToPlayers[clientSocketFD] = player;

}

void changePlayerDirection(player_t &player, bool rightPressed) {

    // change Direction
    if (player.dir == up && !rightPressed) {
        player.dir = left;
    } else if (player.dir == left && rightPressed) {
        player.dir = up;
    } else {
        if (rightPressed) {
            // Cast needed because enums cannot increment (without overriding an operator)
            player.dir = static_cast<Direction>(static_cast<int>(player.dir) + 1);
        } else {
            player.dir = static_cast<Direction>(static_cast<int>(player.dir) - 1);
        }
    }

    // Change Arrow-direction
    switch (player.dir) {
        case up:
            player.disp_char = '^';
            break;
        case right:
            player.disp_char = '>';
            break;
        case down:
            player.disp_char = 'v';
            break;
        case left:
            player.disp_char = '<';
            break;
        default:
            break;
    }
}

void closeConnectionToClient(int clientSocketFD){
    clients.erase(remove(clients.begin(), clients.end(), clientSocketFD), clients.end());

    close(clientSocketFD);
}

int safeRead(int socketFD, void *ptr, size_t bufferSize){
    char *buffer = (char *) ptr;

    ssize_t rec = 0;
    do {
        int result = read(socketFD, &buffer[rec], bufferSize - rec);
        if (result == -1) {
            return result;
        }
        else if (result == 0) {
            syslog(LOG_INFO, "Client disconnected, aborted read.");
            return result;
        }
        else {
            rec += result;
        }
    }
    while (rec < bufferSize);

    return rec;
}

void onExit(){
    syslog(LOG_INFO, "Stopping LED-Display...");
    TM1637_clear_display();

    syslog(LOG_INFO, "Closing all open connections...");

    for(auto const &clientSocketFD : clients){
        close(clientSocketFD);
    }

    syslog(LOG_INFO, "Server exited successfully! Closing syslog...");
    closelog();

    exit(EXIT_SUCCESS);
}

void setReuseAddrAndPort(int socket){
    int reuse = 1;

    if(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &reuse, sizeof(reuse)) < 0){
        syslog(LOG_INFO, "Setting socket to reuse address and port failed.");
        exit(EXIT_FAILURE);
    }
}

void setNonBlockingMode(int socket){
    if(fcntl(socket, F_SETFL, fcntl(serverSocketFD, F_GETFL) | O_NONBLOCK) < 0){
        syslog(LOG_INFO, "Setting socket to non-blocking mode failed.");
        exit(EXIT_FAILURE);
    }
}

void bindSocket(int socket){
    if(bind(socket, (struct sockaddr *) &address, sizeof(address)) < 0){
        syslog(LOG_INFO, "Failed to bind server to address and port.");
        exit(EXIT_FAILURE);
    }
}

void setListenMode(int socket){
    if(listen(socket, 3) < 0){
        syslog(LOG_INFO, "Listen failed.");
        exit(EXIT_FAILURE);
    }
}