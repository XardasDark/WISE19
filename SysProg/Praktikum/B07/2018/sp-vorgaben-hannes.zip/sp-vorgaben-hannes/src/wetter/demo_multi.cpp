//
// Created by chris on 13.12.2018.
//

#include <curl/curl.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include "wetter/loader.h"
//#include "wetter/xmlParser.h"

using namespace std;

int main(void) {
    loader ld;
    string buffer;

    ld.loadData();
    ld.printBuffer();
    /*xmlParser parser;
    parser.parse(buffer);
    std::cout << parser.getTemp() << std::endl;*/
    return 0;
}

