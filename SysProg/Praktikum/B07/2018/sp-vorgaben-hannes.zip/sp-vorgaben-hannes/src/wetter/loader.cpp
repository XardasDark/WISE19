//
// Created by chris on 13.12.2018.
//

/**
 * Loads a website's content
 */

#include <curl/curl.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include "wetter/loader.h"

/**
 * Default constructor
 */
loader::loader() {
    buffer = "";
}

/**
 * Destructor
 */
loader::~loader() {
}

/**
 * Copy-constructor
 *
 * @param c instance of loader to copy buffer from
 */
loader::loader(const loader &c) {
    buffer = c.buffer;
}

/**
 * Zuweisungsoperator
 *
 * @param z instance of loader to assign from
 * @return loader& reference of itself
 */
loader &loader::operator=(const loader &z) {
    if (this != &z) {
        buffer = z.buffer;
    }
    return *this;
}

/**
 * fetches weather data via CURL
 */
void loader::loadData(void) {
    buffer = "";
    CURL *curl;
    CURLcode res;

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, WEATHER_URL);

        /* send all data to this function  */
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, f);

        /* we pass our string buffer to the callback function */
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &buffer);

        /* some servers don't like requests that are made without a user-agent
        field, so we provide one */
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "libcurl-agent/1.0");

        /* Perform the request, res will get the return code */
        res = curl_easy_perform(curl);

        /* Check for errors */
        if (res != CURLE_OK)
            fprintf(stderr, "curl_easy_perform() failed: %s\n",
                    curl_easy_strerror(res));

        /* always cleanup */
        curl_easy_cleanup(curl);
    }
}

void loader::printBuffer(void) {
    std::cout << buffer << std::endl;
}


/**
 * Callback-function to write the fetched XML-data into the string buffer
 * @param data ptr to the fetched data
 * @param userdata ptr to the buffer
 * @return true size of used memory
 */
size_t loader::f(char *data, size_t size, size_t nmemb, void *userdata) {
    size_t realsize = size * nmemb;
    std::string *mem = (std::string *) userdata;
    for (unsigned int i = 0; i < realsize; i++) {
        *mem += *data++;
    }
    return realsize;

}

