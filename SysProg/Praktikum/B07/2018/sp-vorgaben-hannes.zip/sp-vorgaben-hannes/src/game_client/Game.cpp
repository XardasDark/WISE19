//
// Created by chris on 03.01.2019.
//

#include <string>
#include <unistd.h>
#include <locale.h>
#include <wchar.h>
#include <stdio.h>
#include <cstdint>
#include <vector>
#include <map>
#include <errno.h>

#include <cstring>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>

#include "game/Game.h"

using namespace std;

WINDOW* mainWnd;
WINDOW* gameWnd;

rect game_area;
rect screen_area;

vec2ui cur_size;

int highScore = 0;

//char *chars = "^>v<";
        //{L"\x2191", L"\x2192", L"\x2193", L"\x2190"};

// The field
cell field[TERMINAL_WIDTH][TERMINAL_HEIGHT];
map<int, char*> colorStrings;

// The player
int ownColor;
vector<player_t> players;
int playerCount;
int clientSocketFD;

bool initClientSocket(const char*);
void run(void);
void initGame(void);
void readPlayerList(void);
void updateScoreboard(void);

void inLobby(bool);
void inLobby();
void inPreLobby(void);
void joinGame(void);
void hostAndPlay(void);

bool isGameOver(void);
string getStringInput(WINDOW*, int, int, int);

int init() {



    srand(time(0));

    // ncurses init
    mainWnd = initscr();
    cbreak();
    noecho();
    clear();
    refresh();

    curs_set(0);

    start_color();

    // define window areas
    //
    screen_area = { { 0, 0 }, { TERMINAL_WIDTH, TERMINAL_HEIGHT } };
    gameWnd = newwin(  screen_area.height () - 2,
                        screen_area.width() - 2,
                        screen_area.top() + 1,
                        screen_area.left() + 1 );

    mainWnd = newwin(screen_area.height(), screen_area.width(), 0, 0);

    game_area = { { 0, 0 }, { screen_area.width() - 3, screen_area.height() - 3} };

    // useful color pairs
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    colorStrings[1] = "WHITE";

    init_pair(2, COLOR_GREEN, COLOR_BLACK);
    colorStrings[2] = "GREEN";

    init_pair(3, COLOR_YELLOW, COLOR_BLACK);
    colorStrings[3] = "YELLOW";

    init_pair(4, COLOR_RED, COLOR_BLACK);
    colorStrings[4] = "RED";

    init_pair(5, COLOR_BLUE, COLOR_BLACK);
    colorStrings[5] = "BLUE";

    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
    colorStrings[6] = "PINKY";

    init_pair(7, COLOR_CYAN, COLOR_BLACK);
    colorStrings[7] = "CYAN";



    init_pair(8, COLOR_BLACK, COLOR_WHITE);

    // For textboxes
    init_pair(9, COLOR_BLACK, COLOR_CYAN);

    // enable function keys
    keypad(mainWnd, true);
    keypad(gameWnd, true);

    // disable input blocking
    nodelay(mainWnd, true);
    nodelay(gameWnd, true);

    // color check
    if(!has_colors()) {
        endwin();
        printf("ERROR: Terminal does not support color.\n");
        exit(1);
    }

    // Background color for borders
    //wbkgd(mainWnd, COLOR_PAIR(6));

    //Init field with empty cells
    for(int x = 0; x < TERMINAL_WIDTH; x++){
        for(int y = 0; y < TERMINAL_HEIGHT; y++){
            field[x][y] = { (char) 0, -1 };
        }
    }

    return 0;
}

int safeRead(int socketFD, void *ptr, size_t bufferSize){
    char *buffer = (char *) ptr;

    ssize_t rec = 0;
    do {
        int result = read(socketFD, &buffer[rec], bufferSize - rec);
        if (result == -1) {
            return result;
        }
        else if (result == 0) {
            printf("Socket disconnected, aborted read.\n");
            return result;
        }
        else {
            rec += result;
        }
    }
    while (rec < bufferSize);

    return rec;
}

void setNonBlockingMode(int socket, bool setNonBlocking){
    if(setNonBlocking){
        if(fcntl(socket, F_SETFL, fcntl(socket, F_GETFL) | O_NONBLOCK) < 0){
            perror("Setting socket to non-blocking mode failed.");
            exit(EXIT_FAILURE);
        }
    }else{
        if(fcntl(socket, F_SETFL, fcntl(socket, F_GETFL) & (~O_NONBLOCK)) < 0){
            perror("Setting socket to blocking mode failed.");
            exit(EXIT_FAILURE);
        }
    }
}

bool initClientSocket(const char *addressStr){
    struct sockaddr_in address;
    struct sockaddr_in serv_addr;

    clientSocketFD = socket(AF_INET, SOCK_STREAM, 0);
    if(clientSocketFD < 0){
        perror("Failed to construct socket.");
        exit(EXIT_FAILURE);
    }

    memset(&serv_addr, '0', sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if(inet_aton(addressStr, &serv_addr.sin_addr) <= 0){
        return false;
    }

    if(connect(clientSocketFD, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
        return false;
    }

    LobbyError serverStatus;
    int err = safeRead(clientSocketFD, &serverStatus, sizeof(serverStatus));

    if(err <= 0){
        closeAll("Socket encountered error or/and was closed.\n");
    }

    if(serverStatus == LobbyError_OK){
        printf("Joined lobby!\n");

    }else if(serverStatus == LobbyError_LOBBY_FULL){
        closeAll("The lobby you tried to join is already full!\n");

    }else if(serverStatus == LobbyError_LOBBY_IN_PROGRESS){
        closeAll("The lobby you tried to join is already in progress!\n");

    }else{
        closeAll("Received unusual message\n");
    }

    return true;
}

void inPreLobby(){
    wclear(mainWnd);
    wclear(gameWnd);

    // draw frame around whole screen
    wattron(mainWnd, A_BOLD);
    box(mainWnd, 0, 0);
    wattroff(mainWnd, A_BOLD);

    // draw dividing line between game and stats (BUGGY!)
    wmove(mainWnd, game_area.bot() + 3, 1);
    //whline(mainWnd, '-', screen_area.width() - 2);
    for(int i = screen_area.left()+7; i < screen_area.right()-5; i+=2) {
        mvwprintw(mainWnd, TERMINAL_HEIGHT - 1, i, "-");
        mvwprintw(mainWnd, 0, i, "-");
    }


    int xpos = game_area.width() / 2 - 8;
    int ypos = game_area.height() / 2 - 2;

    mvwprintw(gameWnd, ypos, xpos , "CORNER-FEVER");
    mvwprintw(gameWnd, ypos + 2, xpos - 6, "Press 'j' to join a server");
    mvwprintw(gameWnd, ypos + 4, xpos - 6, "Press 'h' to host and play");
    mvwprintw(gameWnd, ypos + 6, xpos - 6, "Press 'q' to quit the game");


    wrefresh(mainWnd);
    wrefresh(gameWnd);


    // Join = 1, Host = 2, Exit = 3
    int decision = 0;
    int inChar = 0;

    while(!decision) {
        inChar = wgetch(mainWnd);
        inChar = tolower(inChar);


        switch(inChar) {
            case 'j':
                decision = 1;
                break;
            case 'h':
                decision = 2;
                break;
            case 'q':
                decision = 3;
                break;
            default:
                break;
        }
    }

    if(decision == 1){
        joinGame();

    } else if(decision == 2){
        hostAndPlay();

    } else if(decision == 3){
        closeAll();
    }
}


void joinGame(){
    wclear(gameWnd);


    int xpos = game_area.width() / 2 - 8;
    int ypos = game_area.height() / 2 - 2;

    mvwprintw(gameWnd, ypos, xpos , "Join a server");
    mvwprintw(gameWnd, ypos + 2, xpos - 4, "Enter an IP address:");

    wrefresh(gameWnd);

    bool success = false;
    bool isDone = false;

    while(!isDone){
        string input = getStringInput(gameWnd, xpos - 4, ypos + 3, 20);

        if(input.size() == 0){
            isDone = true;

        } else {
            success = initClientSocket(input.c_str());
            if(success){
                isDone = true;
            }
        }

        if(!isDone && !success){
            wattron(gameWnd, COLOR_PAIR(4));
            mvwprintw(gameWnd, ypos + 4, xpos - 3, "Invalid IP Address");
            wattroff(gameWnd, COLOR_PAIR(4));
            wrefresh(gameWnd);
        }
    }

    if(success == false){
        inPreLobby();
    }else{
        inLobby();
    }

}

void hostAndPlay(){
    pid_t pid;
    switch(pid = fork()){
        case -1: {
            closeAll("Critical error while starting server process.");
            break;
        }
        case (pid_t) 0: {
            // Fork again
            pid_t secondPid;

            switch (secondPid = fork()) {
                case -1: {
                    closeAll("Failed to fork 2");
                    exit(EXIT_FAILURE);
                    break;
                }
                case (pid_t) 0: {
                    // Child3, ready to be demonized

                    if (setsid() < 0) {
                        closeAll("Failed to set session ID");
                        exit(EXIT_FAILURE);
                    }

                    // Set new file permissions
                    umask(0);

                    // Change directory to root
                    chdir("/");

                    // Close all open file descriptors
                    for (int x = sysconf(_SC_OPEN_MAX); x >= 0; x++) {
                        close(x);
                    }

                    open("/dev/null", O_RDWR);
                    dup2(STDIN_FILENO, STDOUT_FILENO);
                    dup2(STDIN_FILENO, STDERR_FILENO);


                    char *argv[] = {"server", (char*) NULL};
                    char *envp[] = {"test", (char*) NULL};

                    // Load new program into memory
                    if (execve("/home/viddie/git/sp-vorgaben/game_server/server", argv, envp) == -1) {
                        closeAll("Failed to execute execve()");
                    }

                    break;
                }
                default: {
                    // Parent2
                    exit(EXIT_SUCCESS);
                    break;
                }
            }
            break;
        }
        default: {
            // Parent1

            usleep(1000000); // 1 sec

            bool success = initClientSocket("127.0.0.1");
            if(!success){
                closeAll("Server creation was unsuccessful.\n");
            }
            inLobby();
            break;
        }
    }
}


void inLobby(){
    inLobby(false);
}

void inLobby(bool fromGameOver){
    wclear(mainWnd);
    wclear(gameWnd);

    // draw frame around whole screen
    wattron(mainWnd, A_BOLD);
    box(mainWnd, 0, 0);
    wattroff(mainWnd, A_BOLD);

    // draw dividing line between game and stats (BUGGY!)
    wmove(mainWnd, game_area.bot() + 3, 1);
    //whline(mainWnd, '-', screen_area.width() - 2);
    for(int i = screen_area.left()+7; i < screen_area.right()-5; i+=2) {
        mvwprintw(mainWnd, TERMINAL_HEIGHT - 1, i, "-");
        mvwprintw(mainWnd, 0, i, "-");
    }


    // store an approx location where text will be centered
    int xpos = game_area.width() / 2 - 8;
    int ypos = game_area.height() / 2 - 2;


    // If the player comes from a gameover, move selection screen a little bit up
    if(fromGameOver){
        ypos -= 4;
    }

    // print game over prompt
    mvwprintw(gameWnd, ypos, xpos , "Lobby - Waiting");
    mvwprintw(gameWnd, ypos + 2, xpos - 6, "Press 's' to start the game");
    mvwprintw(gameWnd, ypos + 4, xpos - 5, "Press 'q' to quit the game");

    if(fromGameOver){
        mvwprintw(gameWnd, ypos + 7, xpos + 4, "Stats");

        int i = 0;
        for(auto const &player : players){
            wattron(gameWnd, COLOR_PAIR(player.color));

            char buffer[10];
            sprintf(buffer, "%8s", colorStrings[player.color]);

            mvwprintw(gameWnd, ypos + 8 + i, xpos - 2, buffer);
            wattroff(gameWnd, COLOR_PAIR(player.color));

            int colorLen = strlen(buffer);

            mvwprintw(gameWnd, ypos + 8 + i, xpos + colorLen - 2, ": %4d", player.currScore);

            i++;
        }
    }


    wrefresh(mainWnd);
    wrefresh(gameWnd);



    setNonBlockingMode(clientSocketFD, true);

    bool exitRequested = false;
    int inChar = 0;

    while(1) {
        inChar = wgetch(mainWnd);
        inChar = tolower(inChar);

        if(inChar == 's') { // start the game
            ServerCommand cmd = ServerCommand_START_GAME;
            write(clientSocketFD, &cmd, sizeof(cmd));

            /*wclear(gameWnd);
            wrefresh(mainWnd);
            wrefresh(gameWnd);*/
            break;


        } else if(inChar == 'q') {
            exitRequested = true;
            ServerCommand cmd = ServerCommand_LEAVE_GAME;
            write(clientSocketFD, &cmd, sizeof(cmd));
            break;
        }

        ServerCommand cmd = ServerCommand_NONE;

        int err = safeRead(clientSocketFD, &cmd, sizeof(cmd));

        if(err < 0){
            if(errno != EAGAIN && errno != EWOULDBLOCK){
                printf("Encountered error while reading from server in lobby.\n");
            }
        }else if(err == 0){
            closeAll("The server closed the connection, aborted game!\n");
        }

        if(cmd == ServerCommand_END_GAME){
            closeAll("The server closed the game!\n");

        } else if(cmd == ServerCommand_START_GAME){
            break;
        }

        wrefresh(gameWnd);

        usleep(10000); // 1 ms
    }

    if(exitRequested){
        inPreLobby();
    }

    initGame();
    run();
    usleep(10000000 * 5);
    closeAll();
}

void initGame(){
    //Wait for init message
    setNonBlockingMode(clientSocketFD, false);


    playerCount = -1;
    int err = safeRead(clientSocketFD, &playerCount, sizeof(playerCount));

    if(err < 0){
        closeAll("There was an unexpected network error while reading the INIT(playerCount) message from the server!\n");
    }else if(err == 0){
        closeAll("The server closed the connection, aborted game!\n");
    }


    ownColor = -1;
    err = safeRead(clientSocketFD, &ownColor, sizeof(ownColor));

    if(err < 0){
        closeAll("There was an unexpected network error while reading the INIT(ownColor) message from the server!\n");
    }else if(err == 0){
        closeAll("The server closed the connection, aborted game!\n");
    }

    readPlayerList();

    wclear(gameWnd);
    wrefresh(mainWnd);
    wrefresh(gameWnd);
}

void readPlayerList(){
    if(playerCount == -1){
        return;
    }

    players.clear();

    for(int i = 0; i < playerCount; i++){
        player_t player;
        int err = safeRead(clientSocketFD, &player, sizeof(player));

        if(err < 0){
            closeAll("There was an unexpected network error while reading the READ(player) message from the server!\n");
        }else if(err == 0){
            closeAll("The server closed the connection, aborted game!\n");
        }

        players.push_back(player);
    }
}

void updateScoreboard(){

    int xPos = 4;
    int yPos = TERMINAL_HEIGHT - 1;

    int temporaryXPos = 0;
    int temporaryYPos = 0;

    // player is of type player_t
    for(auto const &player : players){
        wattron(mainWnd, COLOR_PAIR(player.color));

        if(player.color == ownColor){
            temporaryXPos = xPos;
            temporaryYPos = yPos;

            xPos = 4;
            yPos = 0;
        }

        if(xPos == 4){
            mvwaddch(mainWnd, yPos, xPos, ' ');
            xPos++;
        }

        mvwprintw(mainWnd, yPos, xPos, colorStrings[player.color]);
        xPos += strlen(colorStrings[player.color]);

        mvwprintw(mainWnd, yPos, xPos, "[ ]:");
        if(player.disp_char == 'X'){
            mvwaddch(mainWnd, yPos, xPos+1, 'X');
        }

        xPos += 4;

        char scoreBuffer[10];
        sprintf(scoreBuffer, "%4d", player.currScore);

        int scoreLen = strlen(scoreBuffer);

        for(int i = 0; i < scoreLen; i++){
            mvwaddch(mainWnd, yPos, xPos+i, ' ');
        }

        mvwprintw(mainWnd, yPos, xPos, scoreBuffer);
        xPos += strlen(scoreBuffer);

        mvwprintw(mainWnd, yPos, xPos, " ");
        xPos += 1;


        if(player.color == ownColor){
            xPos = temporaryXPos;
            yPos = temporaryYPos;
        }

        wattroff(mainWnd, COLOR_PAIR(player.color));
    }

    wrefresh(mainWnd);

    //usleep(1000000 * 10);
}

void run() {

    bool exitRequested = false;

    while(1) {

        // read inputs, lowercase all characters
        int inChar = wgetch(mainWnd);
        inChar = tolower(inChar);

        GameCommand cmd = GameCommand_NONE;

        switch(inChar) {
            case 'q':
                exitRequested = true;
                cmd = GameCommand_LEAVE_GAME;
                break;
            case KEY_LEFT:
                cmd = GameCommand_LEFT;
                break;
            case KEY_RIGHT:
                cmd = GameCommand_RIGHT;
                break;
            default:
                break;
        }

        if(cmd != GameCommand_NONE){
            write(clientSocketFD, &cmd, sizeof(cmd));
        }

        if(exitRequested){
            break;

        } else {
            readPlayerList();
            updateScoreboard();

            int err = safeRead(clientSocketFD, field, sizeof(field));
            //printf("NOOOOO");

            if(err < 0){
                printf("YEEES");
                closeAll("Encountered error while fetching field configuration. Aborted game!\n");
            }else if(err == 0){
                closeAll("The server closed the connection, aborted game!\n");
            }

            for(int x = 0; x < TERMINAL_WIDTH; x++){
                for(int y = 0; y < TERMINAL_HEIGHT; y++){
                    cell tempCell = field[x][y];

                    if(tempCell.disp_char == (char) 0){
                        // No draw needed
                    }else{
                        wattron(gameWnd, COLOR_PAIR(tempCell.color));
                        mvwaddch(gameWnd, y, x, tempCell.disp_char);
                        wattroff(gameWnd, COLOR_PAIR(tempCell.color));
                    }
                }
            }

            wrefresh(gameWnd);


            if(isGameOver()){
                wattron(mainWnd, COLOR_PAIR(4));
                mvwprintw(mainWnd, 0, 25, " GAME OVER ");
                wattroff(mainWnd, COLOR_PAIR(4));

                wrefresh(mainWnd);

                usleep(1000000 * 4);

                exitRequested = false;
                break;
            }
        }
    }

    if(!exitRequested){
        inLobby(true);
    }
}

bool isGameOver(){
    for(auto const &player : players){
        if(player.disp_char != 'X'){
            return false;
        }
    }
    return true;
}


string getStringInput(WINDOW* window, int xPos, int yPos, int fieldLength){
    wattron(window, COLOR_PAIR(9));
    for(int i = 0; i < fieldLength; i++){
        mvwaddch(window, yPos, xPos + i, ' ');
    }


    wrefresh(window);

    string toRet;
    bool abort = false;
    bool done = false;

    while(1){
        int inChar = wgetch(mainWnd);
        inChar = tolower(inChar);

        switch(inChar) {
            case '\n':
                done = true;
                break;
            case KEY_BACKSPACE:
                if(toRet.size() == 0){
                    abort = true;
                }else{
                    toRet.pop_back();
                }
                break;
            default:
                if(inChar != ERR){
                    if(toRet.size() == fieldLength){
                        beep();
                    }else {
                        toRet += inChar;
                    }
                }

                break;
        }

        if(done == true){
            wattroff(window, COLOR_PAIR(9));
            return toRet;
        }

        for(int i = 0; i < fieldLength; i++){
            mvwaddch(window, yPos, xPos + i, ' ');
        }

        mvwprintw(window, yPos, xPos, toRet.c_str());
        wrefresh(window);

        if(abort == true){
            toRet.clear();
            wattroff(window, COLOR_PAIR(9));
            return toRet;

        }
    }
}


void closeAll() {
    closeAll("");
}

void closeAll(char *message){
    endwin();
    close(clientSocketFD);

    if(strlen(message) > 0){
        printf(message);
    }

    exit(EXIT_SUCCESS);
}




/*

    ==============================================
    ===================OLD RUN====================
    ==============================================

        wattron(gameWnd, COLOR_PAIR(player.color));
        mvwaddch(gameWnd, posBefore.y, posBefore.x, line);

        // draw new arrow char
        mvwaddch(gameWnd, player.pos.y, player.pos.x, player.disp_char);
        wattroff(gameWnd, COLOR_PAIR(player.color));

        player.currScore++;
        mvwprintw(mainWnd, 0, screen_area.left() + 3, " Score:%4d : Your High Score:%4d ", player.currScore, highScore);

        wrefresh(mainWnd);
        wrefresh(gameWnd);

        if(gameOver) {

            // Set High Score
            if(player.currScore > highScore) {
                highScore = player.currScore;
            }

            // store an approx location where text will be centered
            const int xpos = game_area.width() / 2 - 6;
            const int ypos = game_area.height() / 2 - 2;

            // erase current game content on window and redraw a clean window
            wclear(gameWnd);

            wrefresh(mainWnd);
            wrefresh(gameWnd);

            // print game over prompt
            mvwprintw(gameWnd, ypos, xpos , "GAME OVER");
            mvwprintw(gameWnd, ypos + 2, xpos - 8, "Press 'SPACE' to play again");
            mvwprintw(gameWnd, ypos + 4, xpos - 7, "Press 'q' to quit the game");

            // loop until player either quits or restarts game
            while(1) {
                inChar = wgetch(mainWnd);

                if(inChar == ' ') { // reset all variables and restart game
                    tick = 0;
                    player.pos = {10, 10};
                    player.currScore = 0;
                    inChar = 0;
                    gameOver = false;
                    exitRequested = false;
                    // reset field
                    for ( int i = 0; i < TERMINAL_WIDTH; i++ ) {
                        for (int j = 0; j < TERMINAL_HEIGHT; j++) {
                            field[i][j] = { (char) 0, -1 };
                        }
                    }

                    wclear(gameWnd);
                    wrefresh(mainWnd);
                    wrefresh(gameWnd);
                    break;
                }

                else if(inChar == 'q') {
                    exitRequested = true;
                    break;
                }

                wrefresh(gameWnd);

                tick++;
                usleep(10000); // 1 ms
            }
        }

        if(exitRequested) break;

        tick++;
        // Delay
        //usleep(10000); // 10 ms
        usleep(100000);
        attroff(COLOR_PAIR(player.color));
    }*/