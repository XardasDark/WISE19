//
// Created by chris on 03.01.2019.
//

#include <ncurses.h>
#include "game/GUI.h"
#include "game/Game.h"
#include <string>

using namespace std;

int main(int argv, char** argc) {
    int init_status = init();

    if(init_status == 0)
        inPreLobby();


    return 0;
}