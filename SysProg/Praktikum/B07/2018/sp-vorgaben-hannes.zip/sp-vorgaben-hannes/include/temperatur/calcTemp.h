//
// Created by viddie on 09.12.18.
//

#ifndef SP_VORGABEN_CALCTEMP_H
#define SP_VORGABEN_CALCTEMP_H

#define PI_VOLT 3.3
#define BITS 1024
#define TEMP_CORRECTION 3.0
#define SLEEP_DURATION 10
#define LOOPCOUNT 5

#ifndef NDEBUG
#define printDebug(expr)  printf("%s in '%s'[%d]: %s\n",  \
                                   __FILE__, __func__, \
                                   __LINE__, expr)
#else
#define printDebug(expr)  ;
#endif

#ifdef __cplusplus
extern "C"{
#endif

    float calculateTemperature(int);

#ifdef __cplusplus
}
#endif

#endif //SP_VORGABEN_CALCTEMP_H
