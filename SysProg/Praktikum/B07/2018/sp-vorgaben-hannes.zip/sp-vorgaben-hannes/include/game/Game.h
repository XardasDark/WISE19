//
// Created by chris on 03.01.2019.
//

#ifndef SP_VORGABEN_HANNES_GAME_H
#define SP_VORGABEN_HANNES_GAME_H

#include <ncurses.h>
#include <vector>

using namespace std;

#define TERMINAL_WIDTH 80
#define TERMINAL_HEIGHT 24

#define PORT 7645

// minimum 16-bit unsigned int 2D vector
typedef struct {
    uint_fast16_t x;
    uint_fast16_t y;
} vec2ui;


// at least 16-bit int 2D vector
typedef struct {
    int_fast16_t x;
    int_fast16_t y;
} vec2i;


// simple integer rectangle type
typedef struct {
    vec2i offset;
    vec2i bounds;

    uint_fast16_t top() { return offset.y; }
    uint_fast16_t bot() { return offset.y + bounds.y; }
    uint_fast16_t left() { return offset.x; }
    uint_fast16_t right() { return offset.x + bounds.x; }

    uint_fast16_t width() { return bounds.x; }
    uint_fast16_t height() { return bounds.y; }

    bool contains(vec2i a) { return (a.x >= offset.x && a.x < right()) &&
                                    (a.y >= offset.y && a.y < bot()); }
} rect;

enum Direction {
    up,
    right,
    down,
    left
};

typedef struct {
    vec2i pos;
    Direction dir;
    char disp_char;
    int currScore;
    int color;
} player_t;

typedef struct{
    char disp_char;
    int color;
} cell;

typedef struct {
    vector<player_t> players;
    cell field[TERMINAL_WIDTH][TERMINAL_HEIGHT];
} configuration;

enum LobbyError {
    LobbyError_OK = 1,
    LobbyError_LOBBY_FULL = 2,
    LobbyError_LOBBY_IN_PROGRESS = 3
};

enum ServerCommand {
    ServerCommand_START_GAME = 11,
    ServerCommand_RESTART_GAME = 12,
    ServerCommand_LEAVE_GAME = 13,
    ServerCommand_END_GAME = 14,
    ServerCommand_NONE = 15
};

enum GameCommand {
    GameCommand_NONE = 21,
    GameCommand_LEFT = 22,
    GameCommand_RIGHT = 23,
    GameCommand_LEAVE_GAME = 24
};

int init();
void inPreLobby();
void closeAll();
void closeAll(char*);

#endif //SP_VORGABEN_HANNES_GAME_H
